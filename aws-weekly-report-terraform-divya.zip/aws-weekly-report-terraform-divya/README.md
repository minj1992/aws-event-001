# AWS Weekly Resource Report — Terraform (Enterprise Structure)
### Jira: DEV-8

---

## Module File Structure

```
modules/aws-weekly-report/
├── locals.tf        # Shared locals and data sources
├── iam.tf           # All IAM roles and policies
├── s3.tf            # CloudTrail log S3 bucket
├── cloudwatch.tf    # Log groups and metric alarms
├── cloudtrail.tf    # CloudTrail trail
├── dynamodb.tf      # DynamoDB event store table
├── lambda.tf        # Both Lambda functions + permissions
├── eventbridge.tf   # EventBridge rule + scheduler
├── ses.tf           # SES email identities
├── variables.tf     # All input variables with validation
└── outputs.tf       # All resource outputs
```

---

## Environments

```
environments/
├── dev/
│   ├── main.tf              # Module call
│   ├── variables.tf         # Variable declarations
│   ├── outputs.tf           # Output declarations
│   └── terraform.tfvars     # DEV values ← edit this
└── prod/
    └── terraform.tfvars     # PROD values ← edit this
```

---

## Deploy DEV

```bash
# Step 1 — Edit emails in tfvars
vim environments/dev/terraform.tfvars

# Step 2 — Init
cd environments/dev
terraform init

# Step 3 — Preview
terraform plan

# Step 4 — Apply
terraform apply
```

## Deploy PROD

```bash
cd environments/prod
terraform init
terraform plan
terraform apply
```

---

## Add / remove email recipients

Edit `ses_recipient_emails` in the environment's `terraform.tfvars`:

```hcl
ses_recipient_emails = [
  "person1@domain.com",
  "person2@domain.com",   # add new line
]
```

Then: `terraform apply`

---

## Dev vs Prod config differences

| Variable | Dev | Prod |
|---|---|---|
| `dynamodb_pitr_enabled` | false | true |
| `s3_force_destroy` | true | false |
| `s3_log_expiry_days` | 90 | 365 |
| `cloudwatch_log_retention_days` | 30 | 90 |

---

## Destroy

```bash
cd environments/dev
terraform destroy
```
