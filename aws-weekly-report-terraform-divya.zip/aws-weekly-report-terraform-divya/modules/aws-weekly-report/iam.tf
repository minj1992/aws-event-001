# ============================================================
# modules/aws-weekly-report — iam.tf
# All IAM roles and policy attachments
# ============================================================

# ─────────────────────────────────────────
# Lambda execution role
# Shared by both Lambda functions
# ─────────────────────────────────────────

resource "aws_iam_role" "lambda_execution" {
  name        = "${local.name_prefix}-lambda-role"
  description = "Lambda execution role for AWS weekly resource report"
  tags        = local.common_tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "lambda_dynamodb" {
  role       = aws_iam_role.lambda_execution.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess"
}

resource "aws_iam_role_policy_attachment" "lambda_ses" {
  role       = aws_iam_role.lambda_execution.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSESFullAccess"
}

resource "aws_iam_role_policy_attachment" "lambda_cloudwatch" {
  role       = aws_iam_role.lambda_execution.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess"
}

resource "aws_iam_role_policy_attachment" "lambda_cloudtrail_read" {
  role       = aws_iam_role.lambda_execution.name
  policy_arn = "arn:aws:iam::aws:policy/AWSCloudTrail_ReadOnlyAccess"
}

# ─────────────────────────────────────────
# CloudTrail → CloudWatch Logs role
# Allows CloudTrail to push logs to CW
# ─────────────────────────────────────────

resource "aws_iam_role" "cloudtrail_cloudwatch" {
  name        = "${local.name_prefix}-cloudtrail-cw-role"
  description = "Allows CloudTrail to write events to CloudWatch Logs"
  tags        = local.common_tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "cloudtrail.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "cloudtrail_cloudwatch_logs" {
  name = "${local.name_prefix}-cloudtrail-cw-policy"
  role = aws_iam_role.cloudtrail_cloudwatch.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ]
      Resource = "${aws_cloudwatch_log_group.cloudtrail.arn}:*"
    }]
  })
}

# ─────────────────────────────────────────
# EventBridge Scheduler role
# Allows scheduler to invoke report Lambda
# ─────────────────────────────────────────

resource "aws_iam_role" "eventbridge_scheduler" {
  name        = "${local.name_prefix}-eventbridge-scheduler-role"
  description = "Allows EventBridge Scheduler to invoke the weekly report Lambda"
  tags        = local.common_tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "scheduler.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "eventbridge_invoke_lambda" {
  name = "${local.name_prefix}-eventbridge-invoke-lambda-policy"
  role = aws_iam_role.eventbridge_scheduler.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "lambda:InvokeFunction"
      Resource = aws_lambda_function.report_sender.arn
    }]
  })
}
