# ============================================================
# modules/aws-weekly-report — locals.tf
# Shared locals and data sources used across all resource files
# ============================================================

data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

locals {
  name_prefix  = "${var.project_name}-${var.environment}"
  account_id   = data.aws_caller_identity.current.account_id
  region       = data.aws_region.current.name

  common_tags = merge(var.tags, {
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "Terraform"
    JiraTicket  = "DEV-8"
  })
}
