# ============================================================
# modules/aws-weekly-report — variables.tf
# ============================================================

# ─── Core ────────────────────────────────

variable "project_name" {
  description = "Project name — used as prefix for all resource names"
  type        = string
  default     = "aws-weekly-report"

  validation {
    condition     = can(regex("^[a-z0-9-]+$", var.project_name))
    error_message = "project_name must be lowercase, alphanumeric and hyphens only."
  }
}

variable "environment" {
  description = "Deployment environment (dev | staging | prod)"
  type        = string

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of: dev, staging, prod."
  }
}

variable "aws_region" {
  description = "AWS region where all resources will be deployed"
  type        = string
  default     = "us-east-1"
}

variable "tags" {
  description = "Additional tags to apply to every resource"
  type        = map(string)
  default     = {}
}

# ─── Lambda ──────────────────────────────

variable "lambda_runtime" {
  description = "Lambda runtime version"
  type        = string
  default     = "python3.12"

  validation {
    condition     = contains(["python3.11", "python3.12"], var.lambda_runtime)
    error_message = "lambda_runtime must be python3.11 or python3.12."
  }
}

# ─── SES ─────────────────────────────────

variable "ses_sender_email" {
  description = "SES verified sender email address"
  type        = string

  validation {
    condition     = can(regex("^[^@]+@[^@]+\\.[^@]+$", var.ses_sender_email))
    error_message = "ses_sender_email must be a valid email address."
  }
}

variable "ses_recipient_emails" {
  description = "List of recipient email addresses for the weekly report. In SES sandbox all must be verified."
  type        = list(string)

  validation {
    condition     = length(var.ses_recipient_emails) > 0
    error_message = "At least one recipient email must be provided."
  }

  validation {
    condition = alltrue([
      for e in var.ses_recipient_emails : can(regex("^[^@]+@[^@]+\\.[^@]+$", e))
    ])
    error_message = "All ses_recipient_emails must be valid email addresses."
  }
}

# ─── EventBridge Schedule ────────────────

variable "report_schedule_cron" {
  description = "Cron expression for weekly report (UTC). Default = Monday 2:00 AM UTC = 7:30 AM IST"
  type        = string
  default     = "cron(0 2 ? * MON *)"
}

# ─── CloudWatch ──────────────────────────

variable "cloudwatch_log_retention_days" {
  description = "CloudWatch log retention in days"
  type        = number
  default     = 30

  validation {
    condition     = contains([1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, 3653], var.cloudwatch_log_retention_days)
    error_message = "cloudwatch_log_retention_days must be a valid AWS CloudWatch retention value."
  }
}

# ─── DynamoDB ────────────────────────────

variable "dynamodb_pitr_enabled" {
  description = "Enable DynamoDB point-in-time recovery. Recommended true for prod."
  type        = bool
  default     = false
}

# ─── S3 ──────────────────────────────────

variable "s3_force_destroy" {
  description = "Allow Terraform to destroy S3 bucket even if it has objects. Set true for dev only."
  type        = bool
  default     = false
}

variable "s3_log_expiry_days" {
  description = "Number of days after which CloudTrail log objects are deleted from S3"
  type        = number
  default     = 365
}
