# ============================================================
# modules/aws-weekly-report — dynamodb.tf
# DynamoDB table — stores all resource events with TTL
# ============================================================

resource "aws_dynamodb_table" "resource_events" {
  name         = "${local.name_prefix}-resource-events"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "resourceType"
  range_key    = "eventId"
  tags         = local.common_tags

  # ── Keys ──────────────────────────────
  attribute {
    name = "resourceType"
    type = "S"
  }

  attribute {
    name = "eventId"
    type = "S"
  }

  # ── TTL — auto-expire items after 30 days ──
  ttl {
    attribute_name = "ttl"
    enabled        = true
  }

  # ── Point-in-time recovery (enabled for prod) ──
  point_in_time_recovery {
    enabled = var.dynamodb_pitr_enabled
  }

  # ── Server-side encryption ──
  server_side_encryption {
    enabled = true
  }
}
