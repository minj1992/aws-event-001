# ============================================================
# environments/dev — main.tf
# ============================================================

terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # Uncomment to enable remote state
  # backend "s3" {
  #   bucket  = "your-tfstate-bucket"
  #   key     = "aws-weekly-report/dev/terraform.tfstate"
  #   region  = "us-east-1"
  #   encrypt = true
  # }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "aws-weekly-report"
      Environment = "dev"
      ManagedBy   = "Terraform"
      JiraTicket  = "DEV-8"
    }
  }
}

module "aws_weekly_report" {
  source = "../../modules/aws-weekly-report"

  # ── Core
  project_name = var.project_name
  environment  = var.environment
  aws_region   = var.aws_region
  tags         = var.tags

  # ── Lambda
  lambda_runtime = var.lambda_runtime

  # ── SES
  ses_sender_email     = var.ses_sender_email
  ses_recipient_emails = var.ses_recipient_emails

  # ── EventBridge
  report_schedule_cron = var.report_schedule_cron

  # ── CloudWatch
  cloudwatch_log_retention_days = var.cloudwatch_log_retention_days

  # ── S3
  s3_force_destroy   = var.s3_force_destroy
  s3_log_expiry_days = var.s3_log_expiry_days
}
