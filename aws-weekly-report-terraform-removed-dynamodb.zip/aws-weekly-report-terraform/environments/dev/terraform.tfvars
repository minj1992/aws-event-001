# ============================================================
# environments/dev — terraform.tfvars
# Edit values here before running terraform apply
# ============================================================

# ─── Core ────────────────────────────────
project_name = "aws-weekly-report"
environment  = "dev"
aws_region   = "us-east-1"

# ─── Lambda ──────────────────────────────
lambda_runtime = "python3.12"

# ─── SES ─────────────────────────────────
# All emails must be SES verified (sandbox mode)
ses_sender_email = "test@test.com"

ses_recipient_emails = [
    "test@test.com",
    "test1@test.com"
]

# ─── Schedule ────────────────────────────
# Monday 2:00 AM UTC = 7:30 AM IST
report_schedule_cron = "cron(0 2 ? * MON *)"

# ─── CloudWatch ──────────────────────────
cloudwatch_log_retention_days = 30

# ─── S3 ──────────────────────────────────
s3_force_destroy   = true    # safe to destroy dev bucket
s3_log_expiry_days = 91      # shorter retention for dev

# ─── Tags ────────────────────────────────
tags = {
  Owner      = "devops-team"
  CostCenter = "engineering"
  JiraTicket = "DEV-8"
}
