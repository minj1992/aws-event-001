# ============================================================
# environments/dev — outputs.tf
# ============================================================

output "iam_lambda_role_name"               { value = module.aws_weekly_report.iam_lambda_role_name }
output "s3_cloudtrail_bucket_name"          { value = module.aws_weekly_report.s3_cloudtrail_bucket_name }
output "s3_events_prefix"                   { value = module.aws_weekly_report.s3_events_prefix }
output "cloudtrail_name"                    { value = module.aws_weekly_report.cloudtrail_name }
output "lambda_event_processor_name"        { value = module.aws_weekly_report.lambda_event_processor_name }
output "lambda_report_sender_name"          { value = module.aws_weekly_report.lambda_report_sender_name }
output "eventbridge_rule_name"              { value = module.aws_weekly_report.eventbridge_rule_name }
output "eventbridge_schedule_name"          { value = module.aws_weekly_report.eventbridge_schedule_name }
output "cloudwatch_log_group_event_processor" { value = module.aws_weekly_report.cloudwatch_log_group_event_processor }
output "cloudwatch_log_group_report_sender"   { value = module.aws_weekly_report.cloudwatch_log_group_report_sender }
