# ============================================================
# environments/dev — variables.tf
# ============================================================

variable "project_name"  { type = string }
variable "environment"   { type = string }
variable "aws_region"    { type = string }
variable "lambda_runtime" { type = string }

variable "ses_sender_email"     { type = string }
variable "ses_recipient_emails" { type = list(string) }

variable "report_schedule_cron"          { type = string }
variable "cloudwatch_log_retention_days" { type = number }
variable "s3_force_destroy"              { type = bool }
variable "s3_log_expiry_days"            { type = number }

variable "tags" {
  type    = map(string)
  default = {}
}
