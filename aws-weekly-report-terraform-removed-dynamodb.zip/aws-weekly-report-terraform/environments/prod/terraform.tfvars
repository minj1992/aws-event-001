# ============================================================
# environments/prod — terraform.tfvars
# ============================================================

# ─── Core ────────────────────────────────
project_name = "aws-weekly-report"
environment  = "prod"
aws_region   = "us-east-1"

# ─── Lambda ──────────────────────────────
lambda_runtime = "python3.12"

# ─── SES ─────────────────────────────────
ses_sender_email = "reports@yourdomain.com"

ses_recipient_emails = [
  "devops-lead@yourdomain.com",
  "manager@yourdomain.com",
  "team-member1@yourdomain.com",
  "team-member2@yourdomain.com",
  "team-member3@yourdomain.com",
]

# ─── Schedule ────────────────────────────
report_schedule_cron = "cron(0 2 ? * MON *)"

# ─── CloudWatch ──────────────────────────
cloudwatch_log_retention_days = 90

# ─── S3 ──────────────────────────────────
s3_force_destroy   = false   # protect prod logs
s3_log_expiry_days = 365     # 1 year retention for prod

# ─── Tags ────────────────────────────────
tags = {
  Owner      = "devops-team"
  CostCenter = "engineering"
  JiraTicket = "DEV-8"
}
