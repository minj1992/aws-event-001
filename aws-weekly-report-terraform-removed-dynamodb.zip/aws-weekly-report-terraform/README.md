# AWS Weekly Resource Report — Terraform (Enterprise Structure)
### Jira: DEV-8

---

## Module File Structure

```
modules/aws-weekly-report/
├── locals.tf        # Shared locals and data sources (incl. s3_events_prefix)
├── iam.tf           # All IAM roles and policies
├── s3.tf            # S3 bucket (CloudTrail logs + resource events)
├── cloudwatch.tf    # Log groups and metric alarms
├── cloudtrail.tf    # CloudTrail trail
├── lambda.tf        # Both Lambda functions + permissions
├── eventbridge.tf   # EventBridge rule + scheduler
├── ses.tf           # SES email identities
├── variables.tf     # All input variables with validation
└── outputs.tf       # All resource outputs
```

---

## Environments

```
environments/
├── dev/
│   ├── main.tf              # Module call
│   ├── variables.tf         # Variable declarations
│   ├── outputs.tf           # Output declarations
│   └── terraform.tfvars     # DEV values ← edit this
└── prod/
    └── terraform.tfvars     # PROD values ← edit this
```

---

## Deploy DEV

```bash
# Step 1 — Edit emails in tfvars
vim environments/dev/terraform.tfvars

# Step 2 — Init
cd environments/dev
terraform init

# Step 3 — Preview
terraform plan

# Step 4 — Apply
terraform apply
```

## Deploy PROD

```bash
cd environments/prod
terraform init
terraform plan
terraform apply
```

---

## Add / remove email recipients

Edit `ses_recipient_emails` in the environment's `terraform.tfvars`:

```hcl
ses_recipient_emails = [
  "person1@domain.com",
  "person2@domain.com",   # add new line
]
```

Then: `terraform apply`

---

## Dev vs Prod config differences

| Variable | Dev | Prod |
|---|---|---|
| `s3_force_destroy` | true | false |
| `s3_log_expiry_days` | 90 | 365 |
| `cloudwatch_log_retention_days` | 30 | 90 |

---

## Destroy

```bash
cd environments/dev
terraform destroy
```

---

## DynamoDB Replacement with S3 Bucket

### Why the change was made

The project already provisioned an S3 bucket for CloudTrail logs. Maintaining a separate DynamoDB table purely for event storage added unnecessary cost and infrastructure complexity. Events are now stored as individual JSON files inside the same S3 bucket under a dedicated `resource-events/` prefix, using a `YYYY/MM/DD/<uuid>.json` path structure. This eliminates the DynamoDB table entirely while keeping all data in one place.

---

### Architecture before and after

```
BEFORE                              AFTER

EventBridge                         EventBridge
    |                                   |
    v                                   v
Lambda event-processor              Lambda event-processor
    |                                   |
    v                                   v
DynamoDB table  <-- removed         S3 bucket  (same bucket, new prefix)
                                    resource-events/YYYY/MM/DD/<uuid>.json
    |                                   |
    v                                   v
Lambda report-sender                Lambda report-sender
reads via DynamoDB scan             reads via S3 list + get per day folder
```

---

### Files changed and reason for each change

| File | Change | Reason |
|---|---|---|
| `modules/aws-weekly-report/dynamodb.tf` | **Deleted** | Table no longer needed; S3 replaces it as the event store |
| `modules/aws-weekly-report/locals.tf` | Added `s3_events_prefix = "resource-events/"` | Central definition of the S3 key prefix so all resources reference one value |
| `modules/aws-weekly-report/iam.tf` | Removed `AmazonDynamoDBFullAccess` policy attachment; added `lambda_s3_events` inline policy | Lambda no longer needs DynamoDB access; needs scoped S3 permissions (PutObject, GetObject, DeleteObject on `resource-events/*` and ListBucket with prefix condition) |
| `modules/aws-weekly-report/lambda.tf` | Replaced `DYNAMODB_TABLE` env var with `S3_BUCKET` + `S3_EVENTS_PREFIX` on both Lambdas; updated descriptions and `depends_on` | Lambda code reads from environment variables — switching the variable names connects the functions to S3 instead of DynamoDB |
| `modules/aws-weekly-report/outputs.tf` | Removed `dynamodb_table_name` and `dynamodb_table_arn` outputs; added `s3_events_prefix` output | Output the new storage location reference instead of the deleted table |
| `modules/aws-weekly-report/variables.tf` | Removed `dynamodb_pitr_enabled` variable | Variable only controlled DynamoDB PITR; no longer applicable |
| `lambda-code/event_processor.py` | Full rewrite — stores events as JSON to S3 instead of DynamoDB `put_item` | Writes `resource-events/YYYY/MM/DD/<uuid>.json` to S3; removed `time`/`ttl` fields (S3 lifecycle rules handle expiry instead) |
| `lambda-code/report_sender.py` | Full rewrite — reads events from S3 instead of DynamoDB `scan` | Iterates the last 7 day-prefixes (`resource-events/YYYY/MM/DD/`), lists objects, fetches each JSON file; removed `boto3.dynamodb.conditions` import |
| `environments/dev/main.tf` | Removed `dynamodb_pitr_enabled = var.dynamodb_pitr_enabled` | Variable removed from module; passing it would cause a Terraform error |
| `environments/prod/main.tf` | Removed `dynamodb_pitr_enabled = var.dynamodb_pitr_enabled` | Same reason as dev |
| `environments/dev/variables.tf` | Removed `variable "dynamodb_pitr_enabled"` | Variable declaration for a removed input |
| `environments/prod/variables.tf` | Removed `variable "dynamodb_pitr_enabled"` | Same reason as dev |
| `environments/dev/terraform.tfvars` | Removed `dynamodb_pitr_enabled = false` and the DynamoDB comment block | Value no longer consumed anywhere |
| `environments/prod/terraform.tfvars` | Removed `dynamodb_pitr_enabled = true` and the DynamoDB comment block | Same reason as dev |
| `environments/dev/outputs.tf` | Removed `dynamodb_table_name` and `dynamodb_table_arn`; added `s3_events_prefix` | Outputs must match what the module exposes |
| `environments/prod/outputs.tf` | Removed `dynamodb_table_name` and `dynamodb_table_arn`; added `s3_events_prefix` | Same reason as dev |

---

### S3 event storage structure

Events land in the same bucket as CloudTrail logs, under a separate prefix:

```
aws-weekly-report-dev-trail-logs-us-east-1/
├── cloudtrail-logs/          # CloudTrail managed (unchanged)
│   └── AWSLogs/...
└── resource-events/          # New — written by event_processor Lambda
    └── YYYY/
        └── MM/
            └── DD/
                └── <uuid>.json
```

Each JSON file contains one event:

```json
{
  "eventId":      "8f3c2a...",
  "resourceType": "S3",
  "resourceName": "my-new-bucket",
  "action":       "Created",
  "eventName":    "CreateBucket",
  "timestamp":    "2026-05-21T02:14:33Z",
  "region":       "us-east-1",
  "userRole":     "arn:aws:iam::123456789:role/admin"
}
```

---

### IAM policy added (`lambda_s3_events` inline policy)

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:PutObject", "s3:GetObject", "s3:DeleteObject"],
      "Resource": "arn:aws:s3:::<bucket>/resource-events/*"
    },
    {
      "Effect": "Allow",
      "Action": "s3:ListBucket",
      "Resource": "arn:aws:s3:::<bucket>",
      "Condition": {
        "StringLike": { "s3:prefix": ["resource-events/*"] }
      }
    }
  ]
}
```
