import boto3
import json
import os
import uuid
from datetime import datetime

s3 = boto3.client('s3', region_name=os.environ['REGION'])

S3_BUCKET         = os.environ['S3_BUCKET']
S3_EVENTS_PREFIX  = os.environ['S3_EVENTS_PREFIX']

TRACKED_EVENTS = {
    'RunInstances'           : ('EC2',    'Created'),
    'TerminateInstances'     : ('EC2',    'Deleted'),
    'CreateBucket'           : ('S3',     'Created'),
    'DeleteBucket'           : ('S3',     'Deleted'),
    'CreateDBInstance'       : ('RDS',    'Created'),
    'DeleteDBInstance'       : ('RDS',    'Deleted'),
    'CreateFunction20150331' : ('Lambda', 'Created'),
    'DeleteFunction'         : ('Lambda', 'Deleted'),
    'CreateUser'             : ('IAM',    'Created'),
    'DeleteUser'             : ('IAM',    'Deleted'),
    'CreateVpc'              : ('VPC',    'Created'),
    'DeleteVpc'              : ('VPC',    'Deleted'),
}

def lambda_handler(event, context):
    try:
        detail     = event.get('detail', {})
        event_name = detail.get('eventName', '')

        if event_name not in TRACKED_EVENTS:
            print(f"Skipping untracked event: {event_name}")
            return {'statusCode': 200, 'body': 'Event not tracked'}

        resource_type, action = TRACKED_EVENTS[event_name]

        user_identity = detail.get('userIdentity', {})
        user_role     = user_identity.get('arn',
                        user_identity.get('userName', 'Unknown'))

        resource_name = extract_resource_name(detail, resource_type)

        item = {
            'eventId'      : str(uuid.uuid4()),
            'resourceType' : resource_type,
            'resourceName' : resource_name,
            'action'       : action,
            'eventName'    : event_name,
            'timestamp'    : detail.get('eventTime',
                             datetime.utcnow().isoformat()),
            'region'       : detail.get('awsRegion',
                             os.environ.get('REGION', 'us-east-1')),
            'userRole'     : user_role,
        }

        # Store as: resource-events/YYYY/MM/DD/<uuid>.json
        now    = datetime.utcnow()
        s3_key = (
            f"{S3_EVENTS_PREFIX}"
            f"{now.year}/{now.month:02d}/{now.day:02d}/"
            f"{item['eventId']}.json"
        )

        s3.put_object(
            Bucket      = S3_BUCKET,
            Key         = s3_key,
            Body        = json.dumps(item),
            ContentType = 'application/json'
        )

        print(f"Saved to S3: s3://{S3_BUCKET}/{s3_key}")
        return {'statusCode': 200, 'body': 'Event saved to S3'}

    except Exception as e:
        print(f"ERROR: {str(e)}")
        raise e


def extract_resource_name(detail, resource_type):
    req = detail.get('requestParameters', {})  or {}
    res = detail.get('responseElements',  {})  or {}

    if resource_type == 'EC2':
        instances = res.get('instancesSet', {}).get('items', [])
        if instances:
            return instances[0].get('instanceId', 'Unknown')
    elif resource_type == 'S3':
        return req.get('bucketName', 'Unknown')
    elif resource_type == 'RDS':
        return req.get('dBInstanceIdentifier', 'Unknown')
    elif resource_type == 'Lambda':
        return req.get('functionName', 'Unknown')
    elif resource_type == 'IAM':
        return req.get('userName', 'Unknown')
    elif resource_type == 'VPC':
        return res.get('vpc', {}).get('vpcId', 'Unknown')
    return 'Unknown'
