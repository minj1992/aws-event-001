# ============================================================
# modules/aws-weekly-report — outputs.tf
# ============================================================

# ─── IAM ─────────────────────────────────
output "iam_lambda_role_name" {
  description = "Lambda execution IAM role name"
  value       = aws_iam_role.lambda_execution.name
}

output "iam_lambda_role_arn" {
  description = "Lambda execution IAM role ARN"
  value       = aws_iam_role.lambda_execution.arn
}

# ─── S3 ──────────────────────────────────
output "s3_cloudtrail_bucket_name" {
  description = "S3 bucket name for CloudTrail logs"
  value       = aws_s3_bucket.cloudtrail_logs.bucket
}

output "s3_cloudtrail_bucket_arn" {
  description = "S3 bucket ARN for CloudTrail logs"
  value       = aws_s3_bucket.cloudtrail_logs.arn
}

# ─── CloudTrail ──────────────────────────
output "cloudtrail_name" {
  description = "CloudTrail trail name"
  value       = aws_cloudtrail.main.name
}

output "cloudtrail_arn" {
  description = "CloudTrail trail ARN"
  value       = aws_cloudtrail.main.arn
}

# ─── S3 Events ───────────────────────────
output "s3_events_prefix" {
  description = "S3 key prefix where resource events are stored"
  value       = local.s3_events_prefix
}

# ─── Lambda ──────────────────────────────
output "lambda_event_processor_name" {
  description = "Event processor Lambda function name"
  value       = aws_lambda_function.event_processor.function_name
}

output "lambda_event_processor_arn" {
  description = "Event processor Lambda function ARN"
  value       = aws_lambda_function.event_processor.arn
}

output "lambda_report_sender_name" {
  description = "Report sender Lambda function name"
  value       = aws_lambda_function.report_sender.function_name
}

output "lambda_report_sender_arn" {
  description = "Report sender Lambda function ARN"
  value       = aws_lambda_function.report_sender.arn
}

# ─── EventBridge ─────────────────────────
output "eventbridge_rule_name" {
  description = "EventBridge real-time event rule name"
  value       = aws_cloudwatch_event_rule.resource_events.name
}

output "eventbridge_rule_arn" {
  description = "EventBridge real-time event rule ARN"
  value       = aws_cloudwatch_event_rule.resource_events.arn
}

output "eventbridge_schedule_name" {
  description = "EventBridge Monday scheduler name"
  value       = aws_scheduler_schedule.weekly_report.name
}

# ─── SES ─────────────────────────────────
output "ses_sender_identity" {
  description = "SES verified sender email"
  value       = aws_ses_email_identity.sender.email
}

output "ses_recipient_identities" {
  description = "SES verified recipient emails"
  value       = [for id in aws_ses_email_identity.recipients : id.email]
}

# ─── CloudWatch ──────────────────────────
output "cloudwatch_log_group_cloudtrail" {
  description = "CloudTrail CloudWatch log group name"
  value       = aws_cloudwatch_log_group.cloudtrail.name
}

output "cloudwatch_log_group_event_processor" {
  description = "Event processor Lambda log group name"
  value       = aws_cloudwatch_log_group.event_processor.name
}

output "cloudwatch_log_group_report_sender" {
  description = "Report sender Lambda log group name"
  value       = aws_cloudwatch_log_group.report_sender.name
}
