# ============================================================
# modules/aws-weekly-report — eventbridge.tf
# Two EventBridge resources:
#   1. Rule     — real-time routing of CloudTrail events to Lambda
#   2. Scheduler — Monday cron to trigger weekly report Lambda
# ============================================================

# ─────────────────────────────────────────
# EventBridge Rule — real-time event capture
# Matches CloudTrail create/delete events
# and routes them to event-processor Lambda
# ─────────────────────────────────────────

resource "aws_cloudwatch_event_rule" "resource_events" {
  name        = "${local.name_prefix}-resource-create-delete-rule"
  description = "Routes CloudTrail create and delete events to the event processor Lambda"
  tags        = local.common_tags

  event_pattern = jsonencode({
    source      = ["aws.ec2", "aws.s3", "aws.rds", "aws.lambda", "aws.iam"]
    detail-type = ["AWS API Call via CloudTrail"]
    detail = {
      eventName = [
        # EC2
        "RunInstances",
        "TerminateInstances",
        # S3
        "CreateBucket",
        "DeleteBucket",
        # RDS
        "CreateDBInstance",
        "DeleteDBInstance",
        # Lambda
        "CreateFunction20150331",
        "DeleteFunction",
        # IAM
        "CreateUser",
        "DeleteUser",
        # VPC
        "CreateVpc",
        "DeleteVpc"
      ]
    }
  })
}

resource "aws_cloudwatch_event_target" "event_processor" {
  rule      = aws_cloudwatch_event_rule.resource_events.name
  target_id = "EventProcessorLambdaTarget"
  arn       = aws_lambda_function.event_processor.arn
}

# ─────────────────────────────────────────
# EventBridge Scheduler — Monday cron
# Triggers report-sender Lambda every Monday
# 2:00 AM UTC = 7:30 AM IST
# ─────────────────────────────────────────

resource "aws_scheduler_schedule" "weekly_report" {
  name        = "${local.name_prefix}-weekly-report-schedule"
  description = "Triggers weekly HTML email report every Monday 7:30 AM IST (2:00 AM UTC)"
  group_name  = "default"

  flexible_time_window {
    mode = "OFF"
  }

  schedule_expression          = var.report_schedule_cron
  schedule_expression_timezone = "UTC"

  target {
    arn      = aws_lambda_function.report_sender.arn
    role_arn = aws_iam_role.eventbridge_scheduler.arn
    input    = jsonencode({})

    retry_policy {
      maximum_retry_attempts       = 2
      maximum_event_age_in_seconds = 3600
    }
  }
}
