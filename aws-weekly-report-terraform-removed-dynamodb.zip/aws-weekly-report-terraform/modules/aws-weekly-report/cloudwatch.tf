# ============================================================
# modules/aws-weekly-report — cloudwatch.tf
# CloudWatch Log Groups for CloudTrail and Lambda functions
# ============================================================

# ─────────────────────────────────────────
# CloudTrail log group
# ─────────────────────────────────────────

resource "aws_cloudwatch_log_group" "cloudtrail" {
  name              = "/aws/cloudtrail/${local.name_prefix}-trail"
  retention_in_days = var.cloudwatch_log_retention_days
  tags              = local.common_tags
}

# ─────────────────────────────────────────
# Lambda — event processor log group
# Must exist before Lambda is created
# ─────────────────────────────────────────

resource "aws_cloudwatch_log_group" "event_processor" {
  name              = "/aws/lambda/${local.name_prefix}-event-processor"
  retention_in_days = var.cloudwatch_log_retention_days
  tags              = local.common_tags
}

# ─────────────────────────────────────────
# Lambda — report sender log group
# Must exist before Lambda is created
# ─────────────────────────────────────────

resource "aws_cloudwatch_log_group" "report_sender" {
  name              = "/aws/lambda/${local.name_prefix}-report-sender"
  retention_in_days = var.cloudwatch_log_retention_days
  tags              = local.common_tags
}

# ─────────────────────────────────────────
# CloudWatch Metric Alarm — Lambda errors
# Alerts if event processor errors spike
# ─────────────────────────────────────────

resource "aws_cloudwatch_metric_alarm" "event_processor_errors" {
  alarm_name          = "${local.name_prefix}-event-processor-errors"
  alarm_description   = "Triggers when event processor Lambda has errors"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Errors"
  namespace           = "AWS/Lambda"
  period              = 300
  statistic           = "Sum"
  threshold           = 5
  treat_missing_data  = "notBreaching"
  tags                = local.common_tags

  dimensions = {
    FunctionName = aws_lambda_function.event_processor.function_name
  }
}

resource "aws_cloudwatch_metric_alarm" "report_sender_errors" {
  alarm_name          = "${local.name_prefix}-report-sender-errors"
  alarm_description   = "Triggers when report sender Lambda fails"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Errors"
  namespace           = "AWS/Lambda"
  period              = 300
  statistic           = "Sum"
  threshold           = 1
  treat_missing_data  = "notBreaching"
  tags                = local.common_tags

  dimensions = {
    FunctionName = aws_lambda_function.report_sender.function_name
  }
}
