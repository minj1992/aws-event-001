# ============================================================
# modules/aws-weekly-report — ses.tf
# SES email identity verification
#
# NOTE: Terraform creates the identity and triggers the
# verification email. Each recipient must manually click
# the verification link in their inbox.
# SES sandbox mode: ALL addresses must be verified.
# Production access: only sender needs verification.
# ============================================================

# ─────────────────────────────────────────
# Sender identity
# ─────────────────────────────────────────

resource "aws_ses_email_identity" "sender" {
  email = var.ses_sender_email
}

# ─────────────────────────────────────────
# Recipient identities
# for_each iterates over the emails list
# ─────────────────────────────────────────

resource "aws_ses_email_identity" "recipients" {
  for_each = toset(var.ses_recipient_emails)
  email    = each.value
}
