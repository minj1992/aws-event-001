# ============================================================
# modules/aws-weekly-report — lambda.tf
# Two Lambda functions:
#   1. event-processor  — triggered by EventBridge, writes to DynamoDB
#   2. report-sender    — triggered by scheduler, queries DynamoDB, sends email
# ============================================================

# ─────────────────────────────────────────
# Archive — zip Lambda source files
# ─────────────────────────────────────────

data "archive_file" "event_processor" {
  type        = "zip"
  source_file = "${path.module}/../../lambda-code/event_processor.py"
  output_path = "${path.module}/../../lambda-code/event_processor.zip"
}

data "archive_file" "report_sender" {
  type        = "zip"
  source_file = "${path.module}/../../lambda-code/report_sender.py"
  output_path = "${path.module}/../../lambda-code/report_sender.zip"
}

# ─────────────────────────────────────────
# Lambda 1 — Event Processor
# Invoked per resource event in real time
# ─────────────────────────────────────────

resource "aws_lambda_function" "event_processor" {
  function_name    = "${local.name_prefix}-event-processor"
  description      = "Processes CloudTrail events from EventBridge and writes structured JSON to S3"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.event_processor.output_path
  source_code_hash = data.archive_file.event_processor.output_base64sha256
  handler          = "event_processor.lambda_handler"
  runtime          = var.lambda_runtime
  architectures    = ["x86_64"]
  timeout          = 30
  memory_size      = 128
  tags             = local.common_tags

  environment {
    variables = {
      S3_BUCKET        = aws_s3_bucket.cloudtrail_logs.bucket
      S3_EVENTS_PREFIX = local.s3_events_prefix
      REGION           = local.region
    }
  }

  depends_on = [
    aws_cloudwatch_log_group.event_processor,
    aws_iam_role_policy.lambda_s3_events,
    aws_iam_role_policy_attachment.lambda_cloudwatch
  ]
}

# Allow EventBridge rule to invoke event processor
resource "aws_lambda_permission" "allow_eventbridge_rule" {
  statement_id  = "AllowEventBridgeRuleInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.event_processor.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.resource_events.arn
}

# ─────────────────────────────────────────
# Lambda 2 — Weekly Report Sender
# Invoked every Monday by EventBridge Scheduler
# ─────────────────────────────────────────

resource "aws_lambda_function" "report_sender" {
  function_name    = "${local.name_prefix}-report-sender"
  description      = "Reads last 7 days of events from S3 and sends HTML email report via SES"
  role             = aws_iam_role.lambda_execution.arn
  filename         = data.archive_file.report_sender.output_path
  source_code_hash = data.archive_file.report_sender.output_base64sha256
  handler          = "report_sender.lambda_handler"
  runtime          = var.lambda_runtime
  architectures    = ["x86_64"]
  timeout          = 60
  memory_size      = 256
  tags             = local.common_tags

  environment {
    variables = {
      S3_BUCKET        = aws_s3_bucket.cloudtrail_logs.bucket
      S3_EVENTS_PREFIX = local.s3_events_prefix
      REGION           = local.region
      SES_SENDER       = var.ses_sender_email
      SES_RECIPIENTS   = join(",", var.ses_recipient_emails)
    }
  }

  depends_on = [
    aws_cloudwatch_log_group.report_sender,
    aws_iam_role_policy_attachment.lambda_ses,
    aws_iam_role_policy.lambda_s3_events,
    aws_iam_role_policy_attachment.lambda_cloudwatch
  ]
}
