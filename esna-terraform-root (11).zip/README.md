# esna Azure Platform — Terraform

Infrastructure-as-Code for the **esna** platform on Microsoft Azure (region
`uksouth`), refactored from two flat exported state files into a clean,
**module-per-resource**, **environment-per-folder** layout for `dev`, `qa` and
`prod`.

Everything that differs between environments lives in a single
`<env>.tfvars` file. The module composition (`main.tf`) and the provider /
variable declarations are shared, so the three environments stay in lockstep
and only their *values* diverge.

---

## Directory structure

```
terraform-root/
├── README.md
├── .gitignore
│
├── environments/                  # One root module per environment
│   ├── dev/
│   │   ├── backend.tf             # Remote state (key = dev.terraform.tfstate)
│   │   ├── providers.tf  ──┐      # symlink → ../../global/providers.tf
│   │   ├── variables.tf  ──┤      # symlink → ../../global/variables.tf
│   │   ├── local.tf        │      # dev-only locals
│   │   ├── main.tf         │      # module composition (identical across envs)
│   │   └── dev.tfvars      │      # DEV values
│   ├── qa/
│   │   ├── backend.tf             # key = qa.terraform.tfstate
│   │   ├── providers.tf  ──┤      # symlink → ../../global/providers.tf
│   │   ├── variables.tf  ──┤      # symlink → ../../global/variables.tf
│   │   ├── main.tf         │
│   │   └── qa.tfvars       │      # QA values
│   └── prod/
│       ├── backend.tf             # key = prod.terraform.tfstate
│       ├── providers.tf  ──┤      # symlink → ../../global/providers.tf
│       ├── variables.tf  ──┘      # symlink → ../../global/variables.tf
│       ├── main.tf
│       └── prod.tfvars            # PROD values (hardened / scaled)
│
├── global/                        # Shared, environment-agnostic definitions
│   ├── providers.tf               # terraform{} + required_providers + provider
│   └── variables.tf               # ALL input variable declarations
│
└── modules/                       # Reusable, single-responsibility modules
    ├── resource-group/
    ├── common-tags/
    ├── network/
    ├── virtual-machine/
    ├── managed-disk/
    ├── acr/
    ├── postgres/
    ├── aks/                       # added (cluster present in source data)
    ├── key-vault/                 # added (Key Vault present in source data)
    └── storage-account/           # added (Storage account present in source data)
```

> **About the symlinks.** `providers.tf` and `variables.tf` in each environment
> are symlinks to the canonical files in `global/`. This keeps provider pins and
> variable declarations DRY. Terraform follows them natively. If your tooling or
> a downloaded archive does not preserve symlinks, simply copy
> `global/providers.tf` and `global/variables.tf` into each `environments/<env>/`
> folder instead.

---

## Modules

| Module | Purpose | Key Azure resources |
|---|---|---|
| `common-tags` | Builds one canonical tag map (no Azure resources) | — |
| `resource-group` | A single resource group | `azurerm_resource_group` |
| `network` | Full hub-and-spoke network from data | `azurerm_virtual_network`, `azurerm_subnet`, `azurerm_network_security_group` (+ rules + associations), `azurerm_public_ip`, `azurerm_nat_gateway` (+ associations), `azurerm_bastion_host`, `azurerm_virtual_network_peering`, `azurerm_private_dns_zone` (+ vnet links) |
| `virtual-machine` | One Linux **or** Windows VM + NIC + optional shutdown schedule | `azurerm_network_interface`, `azurerm_linux_virtual_machine` / `azurerm_windows_virtual_machine`, `azurerm_dev_test_global_vm_shutdown_schedule` |
| `managed-disk` | Standalone data disk + optional snapshot | `azurerm_managed_disk`, `azurerm_snapshot` |
| `acr` | Container registry | `azurerm_container_registry` |
| `postgres` | PostgreSQL Flexible Server + databases + config overrides | `azurerm_postgresql_flexible_server`, `..._database`, `..._configuration` |
| `aks` | AKS cluster + user-assigned identity | `azurerm_kubernetes_cluster`, `azurerm_user_assigned_identity` |
| `key-vault` | Key Vault (RBAC) | `azurerm_key_vault` |
| `storage-account` | Storage account (ADLS Gen2 / SFTP capable) | `azurerm_storage_account` |

---

## Resources deployed per environment

Each environment composes the same modules. The table shows the **dev** names;
`qa` and `prod` follow the same pattern with their own names, address space and
sizing.

| Layer | Resource (dev) | Notes |
|---|---|---|
| Resource groups | `esna-rg-hub-dev`, `esna-rg-aks-custer-dev` | hub/app + AKS |
| App VNet | `esna-dev-app-vnet` (`10.140.4.0/22`) | subnets: aks, postgres, bastion, vm |
| Hub VNet | `esna-vn-hub-dev` (`10.14.0.0/23`) | subnets: bastion, firewall, gateway, services |
| Peering | hub ↔ app (both directions) | |
| Egress | 2× NAT gateway + public IPs | app & hub |
| Access | Azure Bastion (hub) | |
| Private DNS | `privatelink.postgres.database.azure.com` | linked to both VNets |
| AKS | `esna-aks-dev` (k8s 1.34.7, Istio, CNI overlay) | system node pool `Standard_D4pds_v6` ×2–3 |
| PostgreSQL | `esna-dev-psql` (Flexible Server, v18, private) | DBs: `esna_app_dev`, `esna_auth_dev` |
| ACR | `esnadevappacr` (Standard) | |
| Key Vault | `esna-dev-app-kv` (RBAC, purge protection) | |
| Storage | `esnadevappstg` (StorageV2, HNS, SFTP) | |
| Disk | `esna-jumpbox-vm1_DataDisk_0` (+ snapshot) | PremiumV2 250 GB |
| VMs | `esna-dev-vm-jumpbox-01/02` (Win), `...-lin01` (Linux) | jumpboxes, auto-shutdown 20:00 |

### Environment differences at a glance

| | dev | qa | prod |
|---|---|---|---|
| App / Hub CIDR | `10.140.4.0/22` / `10.14.0.0/23` | `10.141.4.0/22` / `10.15.0.0/23` | `10.142.4.0/22` / `10.16.0.0/23` |
| AKS SKU tier | Free | Free | **Standard** (uptime SLA) |
| AKS autoscale | 2–3 | 2–4 | **3–6**, zone-spread |
| PostgreSQL SKU | `B_Standard_B2s` | `B_Standard_B2s` | **`GP_Standard_D2s_v3`** |
| PG backups | 7 days | 7 days | **35 days, geo-redundant** |
| ACR | Standard, admin on | Standard, admin on | **Premium, zone-redundant, admin off** |
| Storage | LRS, SFTP on | LRS, SFTP on | **ZRS, SFTP off, private** |
| VM auto-shutdown | on | on | **off** |

---

## Architecture (per environment)

```
                                  Azure Subscription (uksouth)
 ┌──────────────────────────────────────────────────────────────────────────────┐
 │                                                                                │
 │   Resource Group: esna-rg-hub-<env>            Resource Group: esna-rg-aks-... │
 │  ┌───────────────────────────────────────┐   ┌──────────────────────────────┐ │
 │  │ HUB VNet  esna-vn-hub-<env> 10.x.0/23  │   │  AKS  esna-aks-<env>          │ │
 │  │  ┌──────────────┐  ┌────────────────┐  │   │  ┌────────────────────────┐  │ │
 │  │  │ AzureBastion │  │ AzureFirewall  │  │   │  │ System node pool       │  │ │
 │  │  │   Subnet     │  │    Subnet      │  │   │  │ Standard_D4pds_v6 ×N   │  │ │
 │  │  └──────┬───────┘  └────────────────┘  │   │  │ CNI overlay · Istio    │  │ │
 │  │  ┌──────┴───────┐  ┌────────────────┐  │   │  │ Workload Identity/OIDC │  │ │
 │  │  │  Gateway     │  │ hub-services   │──┼─NAT │ └───────────┬────────────┘  │ │
 │  │  │  Subnet      │  │   Subnet       │  │   │              │ (nodes in     │ │
 │  │  └──────────────┘  └────────────────┘  │   │              │  app/aks      │ │
 │  │         Bastion ── jump access          │   │              │  subnet)      │ │
 │  └────────────────────┬────────────────────┘   └──────────────┼──────────────┘ │
 │                       │  VNet peering (hub ↔ app)              │                │
 │  ┌────────────────────┴───────────────────────────────────────┼─────────────┐  │
 │  │ APP VNet  esna-<env>-app-vnet  10.y.4.0/22                  │             │  │
 │  │  ┌─────────────────┐  ┌──────────────────┐  ┌───────────────┴─────────┐  │  │
 │  │  │ snet-aks  (NSG) │  │ snet-vm  (NAT)   │  │ snet-postgres (NSG,     │  │  │
 │  │  │  AKS nodes ◄────┼──┼─ jumpbox VMs     │  │  delegated to PG Flex)  │  │  │
 │  │  └─────────────────┘  │  • win-jumpbox   │  │   ┌──────────────────┐  │  │  │
 │  │  ┌─────────────────┐  │  • win-jumpbox   │  │   │ PostgreSQL Flex  │  │  │  │
 │  │  │ AzureBastion    │  │  • linux-jumpbox │  │   │ esna-<env>-psql  │  │  │  │
 │  │  │  Subnet         │  └────────┬─────────┘  │   │ (private access) │  │  │  │
 │  │  └─────────────────┘           │ + data disk│   └────────┬─────────┘  │  │  │
 │  └────────────────────────────────┼────────────┴────────────┼────────────┘  │  │
 │                                    │                         │               │  │
 │   Private DNS: privatelink.postgres.database.azure.com ──────┘ (A record)    │  │
 │                                    │                                         │  │
 │   Regional / RG-scoped services (esna-rg-hub-<env>):                         │  │
 │   ┌────────────┐   ┌────────────────┐   ┌──────────────────────────────┐    │  │
 │   │ ACR        │   │ Key Vault      │   │ Storage Account (ADLS/SFTP)  │    │  │
 │   │ esna...acr │   │ esna-...-kv    │   │ esna...stg                   │    │  │
 │   └─────┬──────┘   └────────────────┘   └──────────────────────────────┘    │  │
 │         └── images pulled by AKS                                            │  │
 └──────────────────────────────────────────────────────────────────────────────┘

 Legend:  NSG = Network Security Group   NAT = NAT Gateway egress
          <env> = dev | qa | prod        10.x/10.y differ per environment
```

**Flow summary**

1. Operators connect through **Azure Bastion** (no public VM IPs except the
   optional Linux jumpbox) into the jumpbox VMs in the app VNet.
2. **AKS** nodes live in `snet-aks`, use Azure CNI **overlay**, pull images from
   **ACR**, and reach the database privately.
3. **PostgreSQL Flexible Server** is injected into the delegated `snet-postgres`
   subnet and resolved via the **private DNS zone** linked to both VNets.
4. Outbound traffic egresses through **NAT gateways**; **hub ↔ app** VNets are
   peered.

---

## Usage

Prerequisites: Terraform ≥ 1.6, the Azure CLI (`az login`), and a state backend
storage account (see `environments/dev/backend.tf` for the one-time setup
commands).

Secrets are **not** stored in tfvars. Export them before running:

```bash
export TF_VAR_vm_admin_password='<windows-admin-password>'
export TF_VAR_postgres_administrator_password='<pg-admin-password>'
```

Then, from the chosen environment folder:

```bash
cd environments/dev          # or qa / prod

terraform init               # configures the azurerm backend
terraform plan  -var-file=dev.tfvars     -out=tfplan
terraform apply tfplan
```

For qa / prod use `-var-file=qa.tfvars` or `-var-file=prod.tfvars`
respectively.

Format & validate:

```bash
terraform fmt -recursive
terraform validate
```

---

## Design notes & intentional omissions

- **PostgreSQL server parameters.** The source export contained ~550
  `azurerm_postgresql_flexible_server_configuration` blocks. Those are
  Azure-managed *defaults* and are **not** modelled. Use the module's
  `configurations` map for genuine overrides only, e.g.
  `configurations = { max_connections = "200" }`.
- **Monitoring / alert scaffolding.** The Prometheus recording-rule groups,
  data-collection rules/endpoints and metric alerts from the export are
  platform/observability boilerplate. They were left out of the core modules to
  keep them focused; add a dedicated `monitoring` module if you want them under
  IaC.
- **Default ACR scope maps.** `_repositories_pull`, `_repositories_push`, etc.
  are created automatically by Azure and are not managed here.
- **`aks`, `key-vault`, `storage-account` modules** were added beyond the seven
  originally sketched because those resources appear in the source data and the
  brief asked for a dedicated module per resource.
- **State isolation.** Each environment has its own backend state key, so a
  `dev` apply can never affect `prod`.
- **Clean `terraform destroy` (Key Vault & Storage).** The provider is set with
  `key_vault.purge_soft_delete_on_destroy = true` and every environment sets the
  vault's `purge_protection_enabled = false`, so a destroy fully purges the Key
  Vault instead of leaving a soft-deleted, name-reserved remnant. Storage
  accounts hard-delete on destroy; dev/qa additionally set
  `blob_soft_delete_retention_days = 0` and `container_soft_delete_retention_days = 0`
  so no soft-deleted data lingers. The **backend** state storage (created by the
  bootstrap pipeline) is separate and intentionally keeps versioning/soft-delete.
  Note: disabling purge protection lowers protection against accidental prod
  vault deletion — flip it back to `true` in `prod.tfvars` if you want that
  safeguard once teardown testing is done.
```
