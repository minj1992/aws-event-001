# esna Terraform — single pipeline

One pipeline (`IAC/pipelines/pipeline.yml`) does everything. At **Run pipeline**
you choose:

- **Environment**: `dev` | `qa` | `prod`
- **Action**: `plan` | `apply` | `destroy`
- **Azure service connection**: defaults to `ESNARGConnection` (override per run)

## What it does (for the selected environment)

1. **Ensure backend** — creates the state resource group, storage account and
   `tfstate` container **only if they don't already exist** (idempotent).
2. **Plan** — `terraform init` + `validate` + `plan`. With Action = `destroy`
   it runs `plan -destroy`.
3. **Execute** — `terraform apply` of the saved plan.
   - `plan`    → stops after step 2 (no changes made).
   - `apply`   → applies the plan.
   - `destroy` → applies the destroy plan (tears the environment down).

> The manual approval gate was removed for now. To add it back later, either
> turn on an **Approval check** on the `esna-<env>` Environment in the ADO UI,
> or re-add a `ManualValidation` server job before the `execute` stage.

## One-time setup in Azure DevOps

- **Create exactly one pipeline**: Pipelines → New → Azure Repos Git →
  `ESNA-Hub` → Existing YAML → `/IAC/pipelines/pipeline.yml`.
- **Variable group** per env (Pipelines → Library), each with two **secret**
  variables — `vm_admin_password`, `postgres_administrator_password`:
  `esna-dev-secrets`, `esna-qa-secrets`, `esna-prod-secrets`.
- **Environments** (Pipelines → Environments): `esna-dev`, `esna-qa`, `esna-prod`.

## Notes

- The service connection's SPN needs rights to create resource groups and
  storage accounts (Contributor at subscription scope) for the backend step,
  plus access to manage the resources for plan/apply.
- The backend state storage is created once and reused; `destroy` removes your
  infrastructure but leaves the state account in place.
