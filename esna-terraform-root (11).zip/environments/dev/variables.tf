# ---------------------------------------------------------------------------
# global/variables.tf
#
# Shared variable DECLARATIONS for every environment. Each environment root
# symlinks this file in as `variables.tf`; the actual VALUES come from the
# per-environment <env>.tfvars file. Defaults here are deliberately safe /
# minimal so a missing value fails loudly rather than silently.
# ---------------------------------------------------------------------------

# ----------------------------- Meta / identity -----------------------------
variable "subscription_id" {
  description = "Azure subscription ID to deploy into."
  type        = string
}

variable "tenant_id" {
  description = "Azure AD tenant ID."
  type        = string
}

variable "project" {
  description = "Project / application short name."
  type        = string
  default     = "esna"
}

variable "environment" {
  description = "Environment name (dev, qa, prod)."
  type        = string
}

variable "location" {
  description = "Default Azure region."
  type        = string
  default     = "uksouth"
}

variable "owner" {
  description = "Owning team."
  type        = string
  default     = "platform-team"
}

variable "cost_center" {
  description = "Cost center for billing."
  type        = string
  default     = "engineering"
}

variable "extra_tags" {
  description = "Additional tags merged into the standard tag set."
  type        = map(string)
  default     = {}
}

# ----------------------------- Resource groups -----------------------------
variable "resource_groups" {
  description = "Resource groups to create, keyed by logical name. location defaults to var.location."
  type = map(object({
    name     = string
    location = optional(string)
  }))
}

# -------------------------------- Network ----------------------------------
variable "network_resource_group_key" {
  description = "Key into var.resource_groups that owns the network resources."
  type        = string
}

variable "virtual_networks" {
  description = "Virtual networks + subnets (see modules/network for the schema)."
  type = map(object({
    name          = string
    address_space = list(string)
    dns_servers   = optional(list(string), [])
    subnets = map(object({
      name              = string
      address_prefixes  = list(string)
      service_endpoints = optional(list(string), [])
      nsg_key           = optional(string)
      nat_gateway_key   = optional(string)
      delegation = optional(object({
        name         = string
        service_name = string
        actions      = list(string)
      }))
      private_endpoint_network_policies = optional(string, "Disabled")
    }))
  }))
  default = {}
}

variable "network_security_groups" {
  description = "Network security groups + rules."
  type = map(object({
    name = string
    rules = optional(list(object({
      name                       = string
      priority                   = number
      direction                  = string
      access                     = string
      protocol                   = string
      source_port_range          = optional(string, "*")
      destination_port_range     = optional(string, "*")
      source_address_prefix      = optional(string, "*")
      destination_address_prefix = optional(string, "*")
    })), [])
  }))
  default = {}
}

variable "public_ips" {
  description = "Public IP addresses."
  type = map(object({
    name              = string
    sku               = optional(string, "Standard")
    allocation_method = optional(string, "Static")
    zones             = optional(list(string), [])
  }))
  default = {}
}

variable "nat_gateways" {
  description = "NAT gateways."
  type = map(object({
    name                    = string
    sku_name                = optional(string, "Standard")
    idle_timeout_in_minutes = optional(number, 4)
    zones                   = optional(list(string), [])
    public_ip_key           = string
  }))
  default = {}
}

variable "bastion" {
  description = "Optional Azure Bastion host."
  type = object({
    name          = string
    sku           = optional(string, "Basic")
    scale_units   = optional(number, 2)
    vnet_key      = string
    subnet_key    = string
    public_ip_key = string
  })
  default = null
}

variable "peerings" {
  description = "VNet peerings."
  type = map(object({
    name                         = string
    local_vnet_key               = string
    remote_vnet_key              = string
    allow_forwarded_traffic      = optional(bool, false)
    allow_gateway_transit        = optional(bool, false)
    allow_virtual_network_access = optional(bool, true)
    use_remote_gateways          = optional(bool, false)
  }))
  default = {}
}

variable "private_dns_zones" {
  description = "Private DNS zones + VNet links."
  type = map(object({
    name = string
    vnet_links = optional(map(object({
      name                 = string
      vnet_key             = string
      registration_enabled = optional(bool, false)
    })), {})
  }))
  default = {}
}

# ---------------------------------- AKS ------------------------------------
variable "enable_aks" {
  description = "Whether to deploy the AKS cluster."
  type        = bool
  default     = false
}

variable "aks_resource_group_key" {
  description = "Key into var.resource_groups for the AKS cluster."
  type        = string
  default     = null
}

variable "aks" {
  description = "AKS cluster configuration (see modules/aks)."
  type = object({
    name                       = string
    dns_prefix                 = string
    kubernetes_version         = optional(string, "1.34.7")
    sku_tier                   = optional(string, "Free")
    node_subnet_key            = optional(string) # "<vnet_key>/<subnet_key>"
    log_analytics_workspace_id = optional(string)
    admin_group_object_ids     = optional(list(string), [])
    default_node_pool = object({
      name            = optional(string, "agentpool")
      vm_size         = optional(string, "Standard_D4pds_v6")
      auto_scaling    = optional(bool, true)
      node_count      = optional(number, 2)
      min_count       = optional(number, 2)
      max_count       = optional(number, 3)
      max_pods        = optional(number, 110)
      os_disk_size_gb = optional(number, 128)
      os_disk_type    = optional(string, "Managed")
      os_sku          = optional(string, "Ubuntu")
      node_labels     = optional(map(string), {})
      zones           = optional(list(string), [])
    })
    network_profile = optional(object({
      network_plugin      = optional(string, "azure")
      network_plugin_mode = optional(string, "overlay")
      network_policy      = optional(string)
      load_balancer_sku   = optional(string, "standard")
      outbound_type       = optional(string, "loadBalancer")
      dns_service_ip      = optional(string, "10.0.0.10")
      service_cidr        = optional(string, "10.0.0.0/16")
      pod_cidr            = optional(string, "10.244.0.0/16")
    }), {})
    service_mesh = optional(object({
      mode                             = optional(string, "Istio")
      revisions                        = optional(list(string), ["asm-1-28"])
      internal_ingress_gateway_enabled = optional(bool, true)
      external_ingress_gateway_enabled = optional(bool, true)
    }))
  })
  default = null
}

# ------------------------------- PostgreSQL --------------------------------
variable "enable_postgres" {
  description = "Whether to deploy PostgreSQL Flexible Server."
  type        = bool
  default     = false
}

variable "postgres_resource_group_key" {
  description = "Key into var.resource_groups for PostgreSQL."
  type        = string
  default     = null
}

variable "postgres" {
  description = "PostgreSQL configuration (see modules/postgres)."
  type = object({
    name                          = string
    administrator_login           = optional(string, "pgadmin")
    sku_name                      = optional(string, "B_Standard_B2s")
    postgresql_version            = optional(string, "18")
    storage_mb                    = optional(number, 32768)
    storage_tier                  = optional(string, "P4")
    zone                          = optional(string, "1")
    backup_retention_days         = optional(number, 7)
    geo_redundant_backup_enabled  = optional(bool, false)
    public_network_access_enabled = optional(bool, false)
    delegated_subnet_key          = optional(string) # "<vnet_key>/<subnet_key>"
    private_dns_zone_key          = optional(string) # key into var.private_dns_zones
    databases = optional(map(object({
      name      = string
      charset   = optional(string, "UTF8")
      collation = optional(string, "en_US.utf8")
    })), {})
    configurations = optional(map(string), {})
  })
  default = null
}

variable "postgres_administrator_password" {
  description = "PostgreSQL administrator password (set via TF_VAR / secret store, not in tfvars)."
  type        = string
  default     = null
  sensitive   = true
}

# ---------------------------------- ACR ------------------------------------
variable "enable_acr" {
  description = "Whether to deploy the container registry."
  type        = bool
  default     = false
}

variable "acr_resource_group_key" {
  description = "Key into var.resource_groups for the ACR."
  type        = string
  default     = null
}

variable "acr" {
  description = "Container registry configuration (see modules/acr)."
  type = object({
    name                          = string
    sku                           = optional(string, "Standard")
    admin_enabled                 = optional(bool, false)
    public_network_access_enabled = optional(bool, true)
    zone_redundancy_enabled       = optional(bool, false)
  })
  default = null
}

variable "enable_acr_role_assignment" {
  description = <<-EOT
    Whether to create the AcrPull role assignment (AKS kubelet -> ACR).
    Requires the deploying service principal to have rights to write role
    assignments (User Access Administrator or RBAC Administrator). Set to
    false if the pipeline SPN is only Contributor and the AcrPull assignment
    is granted out-of-band.
  EOT
  type        = bool
  default     = true
}

# -------------------------------- Key Vault --------------------------------
variable "enable_key_vault" {
  description = "Whether to deploy the Key Vault."
  type        = bool
  default     = false
}

variable "key_vault_resource_group_key" {
  description = "Key into var.resource_groups for the Key Vault."
  type        = string
  default     = null
}

variable "key_vault" {
  description = "Key Vault configuration (see modules/key-vault)."
  type = object({
    name                          = string
    sku_name                      = optional(string, "standard")
    purge_protection_enabled      = optional(bool, true)
    soft_delete_retention_days    = optional(number, 90)
    public_network_access_enabled = optional(bool, true)
  })
  default = null
}

# ------------------------------ Storage account ----------------------------
variable "enable_storage_account" {
  description = "Whether to deploy the storage account."
  type        = bool
  default     = false
}

variable "storage_account_resource_group_key" {
  description = "Key into var.resource_groups for the storage account."
  type        = string
  default     = null
}

variable "storage_account" {
  description = "Storage account configuration (see modules/storage-account)."
  type = object({
    name                          = string
    account_tier                  = optional(string, "Standard")
    account_replication_type      = optional(string, "LRS")
    access_tier                   = optional(string, "Hot")
    is_hns_enabled                = optional(bool, false)
    sftp_enabled                  = optional(bool, false)
    public_network_access_enabled = optional(bool, true)
    blob_soft_delete_retention_days      = optional(number, 7)
    container_soft_delete_retention_days = optional(number, 7)
  })
  default = null
}

# ------------------------------ Managed disks ------------------------------
variable "enable_managed_disks" {
  description = "Master switch for creating the managed disks in var.managed_disks."
  type        = bool
  default     = true
}

variable "managed_disks" {
  description = "Standalone managed disks, keyed by logical name."
  type = map(object({
    name                 = string
    resource_group_key   = string
    storage_account_type = optional(string, "Premium_LRS")
    create_option        = optional(string, "Empty")
    disk_size_gb         = number
    zone                 = optional(string)
    disk_iops_read_write = optional(number)
    disk_mbps_read_write = optional(number)
    create_snapshot      = optional(bool, false)
    snapshot_name        = optional(string)
  }))
  default = {}
}

# ---------------------------- Virtual machines -----------------------------
variable "enable_virtual_machines" {
  description = "Master switch for creating the jumpbox VMs in var.virtual_machines. Set false in environments that reuse shared jumpboxes."
  type        = bool
  default     = true
}

variable "virtual_machines" {
  description = "Virtual machines, keyed by logical name."
  type = map(object({
    name                     = string
    resource_group_key       = string
    os_type                  = string # "Linux" or "Windows"
    size                     = string
    zone                     = optional(string)
    subnet_key               = string # "<vnet_key>/<subnet_key>"
    public_ip_key            = optional(string)
    enable_shutdown_schedule = optional(bool, false)
    shutdown_time            = optional(string, "2000")
    shutdown_timezone        = optional(string, "UTC")
    os_disk = optional(object({
      caching              = optional(string, "ReadWrite")
      storage_account_type = optional(string, "Premium_LRS")
      disk_size_gb         = optional(number)
    }), {})
    source_image_reference = object({
      publisher = string
      offer     = string
      sku       = string
      version   = optional(string, "latest")
    })
  }))
  default = {}
}

variable "vm_admin_username" {
  description = "Administrator username for all VMs."
  type        = string
  default     = "azureuser"
}

variable "vm_admin_password" {
  description = "Administrator password for Windows VMs (set via TF_VAR / secret store)."
  type        = string
  default     = null
  sensitive   = true
}

variable "vm_ssh_public_key" {
  description = "SSH public key for Linux VMs."
  type        = string
  default     = null
}
