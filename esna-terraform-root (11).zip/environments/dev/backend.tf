# ---------------------------------------------------------------------------
# environments/dev/backend.tf
#
# Remote state for the dev environment, in a DEDICATED storage account that
# is created by pipelines/bootstrap-backend.yml using the dev service
# connection. Each environment is fully isolated: a dev apply can only reach
# dev state.
#
# Auth at 'terraform init' time is provided by the pipeline (ARM_* env vars or
# ARM_ACCESS_KEY from the same service connection) - no secrets stored here.
# ---------------------------------------------------------------------------

terraform {
  backend "azurerm" {
    resource_group_name  = "esna-tfstate-rg-dev"
    storage_account_name = "esnatfstatedev"
    container_name       = "tfstate"
    key                  = "terraform.tfstate"
  }
}
