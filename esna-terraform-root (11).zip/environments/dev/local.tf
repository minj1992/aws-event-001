# ---------------------------------------------------------------------------
# environments/dev/local.tf
# Local values specific to the dev environment.
# ---------------------------------------------------------------------------

locals {
  # Convenience prefix, e.g. "esna-dev". Not required by the modules (which are
  # driven entirely by tfvars) but handy when adding ad-hoc resources here.
  name_prefix = "${var.project}-${var.environment}"
}
