# ===========================================================================
# Environment composition (root module)
#
# This file is identical across dev / qa / prod. Everything that differs
# between environments lives in <env>.tfvars and backend.tf. It wires the
# reusable modules under ../../modules together, passing network outputs
# (subnet / DNS-zone IDs) into the resources that consume them.
# ===========================================================================

# --------------------------- Standard tag set ------------------------------
module "tags" {
  source = "../../modules/common-tags"

  project     = var.project
  environment = var.environment
  owner       = var.owner
  cost_center = var.cost_center
  extra_tags  = var.extra_tags
}

# ----------------------------- Resource groups -----------------------------
module "resource_groups" {
  source   = "../../modules/resource-group"
  for_each = var.resource_groups

  name     = each.value.name
  location = coalesce(each.value.location, var.location)
  tags     = module.tags.tags
}

# -------------------------------- Network ----------------------------------
module "network" {
  source = "../../modules/network"

  location            = var.location
  resource_group_name = module.resource_groups[var.network_resource_group_key].name
  tags                = module.tags.tags

  virtual_networks        = var.virtual_networks
  network_security_groups = var.network_security_groups
  public_ips              = var.public_ips
  nat_gateways            = var.nat_gateways
  bastion                 = var.bastion
  peerings                = var.peerings
  private_dns_zones       = var.private_dns_zones
}

# ---------------------------------- AKS ------------------------------------
module "aks" {
  source = "../../modules/aks"
  count  = var.enable_aks && var.aks != null ? 1 : 0

  name                = var.aks.name
  location            = var.location
  resource_group_name = module.resource_groups[var.aks_resource_group_key].name
  dns_prefix          = var.aks.dns_prefix
  tenant_id           = var.tenant_id
  admin_group_object_ids = var.aks.admin_group_object_ids
  kubernetes_version  = var.aks.kubernetes_version
  sku_tier            = var.aks.sku_tier
  tags                = module.tags.tags

  default_node_pool = merge(var.aks.default_node_pool, {
    vnet_subnet_id = var.aks.node_subnet_key == null ? null : module.network.subnet_ids[var.aks.node_subnet_key]
  })

  network_profile            = var.aks.network_profile
  service_mesh               = var.aks.service_mesh
  log_analytics_workspace_id = var.aks.log_analytics_workspace_id
}

# ------------------------------- PostgreSQL --------------------------------
module "postgres" {
  source = "../../modules/postgres"
  count  = var.enable_postgres && var.postgres != null ? 1 : 0

  name                          = var.postgres.name
  location                      = var.location
  resource_group_name           = module.resource_groups[var.postgres_resource_group_key].name
  administrator_login           = var.postgres.administrator_login
  administrator_password        = var.postgres_administrator_password
  sku_name                      = var.postgres.sku_name
  postgresql_version            = var.postgres.postgresql_version
  storage_mb                    = var.postgres.storage_mb
  storage_tier                  = var.postgres.storage_tier
  zone                          = var.postgres.zone
  backup_retention_days         = var.postgres.backup_retention_days
  geo_redundant_backup_enabled  = var.postgres.geo_redundant_backup_enabled
  public_network_access_enabled = var.postgres.public_network_access_enabled
  delegated_subnet_id           = var.postgres.delegated_subnet_key == null ? null : module.network.subnet_ids[var.postgres.delegated_subnet_key]
  private_dns_zone_id           = var.postgres.private_dns_zone_key == null ? null : module.network.private_dns_zone_ids[var.postgres.private_dns_zone_key]
  databases                     = var.postgres.databases
  configurations                = var.postgres.configurations
  tags                          = module.tags.tags
}

# ---------------------------------- ACR ------------------------------------
module "acr" {
  source = "../../modules/acr"
  count  = var.enable_acr && var.acr != null ? 1 : 0

  name                          = var.acr.name
  location                      = var.location
  resource_group_name           = module.resource_groups[var.acr_resource_group_key].name
  sku                           = var.acr.sku
  admin_enabled                 = var.acr.admin_enabled
  public_network_access_enabled = var.acr.public_network_access_enabled
  zone_redundancy_enabled       = var.acr.zone_redundancy_enabled
  tags                          = module.tags.tags
}

# ----------------------- AKS -> ACR (AcrPull) --------------------------
# Dependency-aware: only created when BOTH the AKS cluster and the ACR are
# enabled. Lets the cluster pull images without ACR admin credentials.
resource "azurerm_role_assignment" "aks_acrpull" {
  count                = var.enable_aks && var.enable_acr && var.enable_acr_role_assignment ? 1 : 0
  scope                = module.acr[0].id
  role_definition_name = "AcrPull"
  principal_id         = module.aks[0].kubelet_identity_object_id
}

# -------------------------------- Key Vault --------------------------------
module "key_vault" {
  source = "../../modules/key-vault"
  count  = var.enable_key_vault && var.key_vault != null ? 1 : 0

  name                          = var.key_vault.name
  location                      = var.location
  resource_group_name           = module.resource_groups[var.key_vault_resource_group_key].name
  tenant_id                     = var.tenant_id
  sku_name                      = var.key_vault.sku_name
  purge_protection_enabled      = var.key_vault.purge_protection_enabled
  soft_delete_retention_days    = var.key_vault.soft_delete_retention_days
  public_network_access_enabled = var.key_vault.public_network_access_enabled
  tags                          = module.tags.tags
}

# ------------------------------ Storage account ----------------------------
module "storage_account" {
  source = "../../modules/storage-account"
  count  = var.enable_storage_account && var.storage_account != null ? 1 : 0

  name                          = var.storage_account.name
  location                      = var.location
  resource_group_name           = module.resource_groups[var.storage_account_resource_group_key].name
  account_tier                  = var.storage_account.account_tier
  account_replication_type      = var.storage_account.account_replication_type
  access_tier                   = var.storage_account.access_tier
  is_hns_enabled                = var.storage_account.is_hns_enabled
  sftp_enabled                  = var.storage_account.sftp_enabled
  public_network_access_enabled = var.storage_account.public_network_access_enabled
  blob_soft_delete_retention_days      = var.storage_account.blob_soft_delete_retention_days
  container_soft_delete_retention_days = var.storage_account.container_soft_delete_retention_days
  tags                          = module.tags.tags
}

# ------------------------------ Managed disks ------------------------------
module "managed_disks" {
  source   = "../../modules/managed-disk"
  for_each = var.enable_managed_disks ? var.managed_disks : {}

  name                 = each.value.name
  location             = var.location
  resource_group_name  = module.resource_groups[each.value.resource_group_key].name
  storage_account_type = each.value.storage_account_type
  create_option        = each.value.create_option
  disk_size_gb         = each.value.disk_size_gb
  zone                 = each.value.zone
  disk_iops_read_write = each.value.disk_iops_read_write
  disk_mbps_read_write = each.value.disk_mbps_read_write
  create_snapshot      = each.value.create_snapshot
  snapshot_name        = each.value.snapshot_name
  tags                 = module.tags.tags
}

# ---------------------------- Virtual machines -----------------------------
module "virtual_machines" {
  source   = "../../modules/virtual-machine"
  for_each = var.enable_virtual_machines ? var.virtual_machines : {}

  name                     = each.value.name
  location                 = var.location
  resource_group_name      = module.resource_groups[each.value.resource_group_key].name
  os_type                  = each.value.os_type
  size                     = each.value.size
  zone                     = each.value.zone
  subnet_id                = module.network.subnet_ids[each.value.subnet_key]
  public_ip_id             = each.value.public_ip_key == null ? null : module.network.public_ip_ids[each.value.public_ip_key]
  admin_username           = var.vm_admin_username
  admin_password           = var.vm_admin_password
  ssh_public_key           = each.value.os_type == "Linux" ? var.vm_ssh_public_key : null
  os_disk                  = each.value.os_disk
  source_image_reference   = each.value.source_image_reference
  enable_shutdown_schedule = each.value.enable_shutdown_schedule
  shutdown_time            = each.value.shutdown_time
  shutdown_timezone        = each.value.shutdown_timezone
  tags                     = module.tags.tags
}
