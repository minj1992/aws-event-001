# ---------------------------------------------------------------------------
# global/providers.tf
#
# Shared Terraform settings and provider configuration. Every environment root
# (environments/<env>) symlinks this file in as `providers.tf` so the provider
# pin and configuration stay identical across dev / qa / prod.
#
# State backend is intentionally NOT configured here: each environment owns its
# own backend.tf so dev / qa / prod keep fully isolated state files.
# ---------------------------------------------------------------------------

terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.66"
    }
  }
}

provider "azurerm" {
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id

  features {
    key_vault {
      # Fully purge the vault on destroy so the name is freed and no
      # soft-deleted remnant remains (requires purge_protection_enabled = false
      # on the vault itself).
      purge_soft_delete_on_destroy    = true
      recover_soft_deleted_key_vaults = true
    }
    resource_group {
      prevent_deletion_if_contains_resources = true
    }
  }
}
