# ===========================================================================
# environments/qa/qa.tfvars
#
# QA environment. Mirrors dev's topology and sizing (cost-optimized) but uses
# QA-specific names and a non-overlapping address space so the environments
# can coexist / be peered without CIDR clashes.
#
# Secrets are passed at apply time:
#   export TF_VAR_vm_admin_password='...'
#   export TF_VAR_postgres_administrator_password='...'
# ===========================================================================

# ---------------------------- Meta / identity ------------------------------
project         = "esna"
# subscription_id and tenant_id are provided at runtime from the Azure DevOps
# Library variable group (esna-<env>-secrets) via TF_VAR_subscription_id /
# TF_VAR_tenant_id - intentionally NOT hardcoded here.
environment     = "qa"
location        = "uksouth"
owner           = "platform-team"
cost_center     = "engineering"

extra_tags = {
  Workload = "esna-platform"
}

# ---- Resource creation toggles (Terraform-side on/off) ----
enable_managed_disks    = false
enable_virtual_machines = false
# AcrPull (AKS->ACR) role assignment. Requires the pipeline SPN to have
# "User Access Administrator"/"RBAC Administrator". If it is only Contributor,
# set this to false and grant AcrPull out-of-band.
enable_acr_role_assignment = true


# ----------------------------- Resource groups -----------------------------
resource_groups = {
  hub = { name = "esna-rg-hub-qa" }
  aks = { name = "esna-rg-aks-custer-qa" }
}

network_resource_group_key = "hub"

# -------------------------------- Network ----------------------------------
virtual_networks = {
  app = {
    name          = "esna-qa-app-vnet"
    address_space = ["10.141.4.0/22"]
    subnets = {
      aks = {
        name              = "esna-qa-snet-aks"
        address_prefixes  = ["10.141.4.0/24"]
        service_endpoints = ["Microsoft.KeyVault", "Microsoft.Storage"]
        nsg_key           = "aks"
      }
      postgres = {
        name              = "esna-qa-snet-postgres"
        address_prefixes  = ["10.141.6.0/29"]
        service_endpoints = ["Microsoft.KeyVault", "Microsoft.Storage"]
        nsg_key           = "postgres"
        delegation = {
          name         = "Microsoft.DBforPostgreSQL/flexibleServers"
          service_name = "Microsoft.DBforPostgreSQL/flexibleServers"
          actions      = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
        }
      }
      bastion = {
        name             = "AzureBastionSubnet"
        address_prefixes = ["10.141.6.128/26"]
      }
      vm = {
        name              = "esna-qa-snet-vm"
        address_prefixes  = ["10.141.7.0/24"]
        service_endpoints = ["Microsoft.KeyVault", "Microsoft.Storage"]
        nat_gateway_key   = "app"
      }
    }
  }

  hub = {
    name          = "esna-vn-hub-qa"
    address_space = ["10.15.0.0/23"]
    subnets = {
      bastion = {
        name              = "AzureBastionSubnet"
        address_prefixes  = ["10.15.0.0/26"]
        service_endpoints = ["Microsoft.KeyVault"]
      }
      firewall = {
        name              = "AzureFirewallSubnet"
        address_prefixes  = ["10.15.0.128/26"]
        service_endpoints = ["Microsoft.KeyVault"]
      }
      gateway = {
        name              = "GatewaySubnet"
        address_prefixes  = ["10.15.0.192/26"]
        service_endpoints = ["Microsoft.KeyVault"]
      }
      services = {
        name              = "hub-services-subnet"
        address_prefixes  = ["10.15.0.64/26"]
        service_endpoints = ["Microsoft.KeyVault"]
        nat_gateway_key   = "hub"
      }
    }
  }
}

network_security_groups = {
  aks      = { name = "esna-qa-snet-aks-nsg" }
  postgres = { name = "esna-qa-snet-postgres-nsg" }
}

public_ips = {
  nat_app     = { name = "esna-qa-nat-pip", sku = "Standard", zones = ["1", "2", "3"] }
  nat_hub     = { name = "esna-nat-hub-qa-pip", sku = "Standard", zones = ["1", "2", "3"] }
  bastion_hub = { name = "esna-vn-hub-qa-bastion", sku = "Standard" }
  jumpbox_lin = { name = "esna-qa-vm-jumpbox-lin01-ip", sku = "Standard" }
}

nat_gateways = {
  app = { name = "esna-qa-app-nat", sku_name = "Standard", public_ip_key = "nat_app" }
  hub = { name = "esna-nat-hub-qa", sku_name = "Standard", public_ip_key = "nat_hub", zones = ["1", "2", "3"] }
}

bastion = {
  name          = "esna-vn-hub-qa-Bastion"
  sku           = "Basic"
  scale_units   = 2
  vnet_key      = "hub"
  subnet_key    = "bastion"
  public_ip_key = "bastion_hub"
}

peerings = {
  hub_to_app = {
    name            = "peer-hub-to-qa"
    local_vnet_key  = "hub"
    remote_vnet_key = "app"
  }
  app_to_hub = {
    name            = "peer-qa-to-hub"
    local_vnet_key  = "app"
    remote_vnet_key = "hub"
  }
}

private_dns_zones = {
  postgres = {
    name = "privatelink.postgres.database.azure.com"
    vnet_links = {
      app = { name = "esna-qa-app-vnet-link", vnet_key = "app" }
      hub = { name = "esna-qa-hub-vnet-link", vnet_key = "hub" }
    }
  }
}

# ---------------------------------- AKS ------------------------------------
enable_aks             = true
aks_resource_group_key = "aks"

aks = {
  name               = "esna-aks-qa"
  dns_prefix         = "esna-aks-qa-dns"
  kubernetes_version = "1.34.7"
  sku_tier           = "Free"
  node_subnet_key    = "app/aks"

  default_node_pool = {
    name            = "agentpool"
    vm_size         = "Standard_D4pds_v6"
    auto_scaling    = true
    node_count      = 2
    min_count       = 2
    max_count       = 4
    max_pods        = 110
    os_disk_size_gb = 220
    os_disk_type    = "Ephemeral"
    os_sku          = "Ubuntu"
    node_labels     = { app = "esnaqa", env = "qa", workload = "esnaapi" }
  }

  network_profile = {
    network_plugin      = "azure"
    network_plugin_mode = "overlay"
    dns_service_ip      = "10.0.0.10"
    service_cidr        = "10.0.0.0/16"
    pod_cidr            = "10.244.0.0/16"
  }

  service_mesh = {
    mode      = "Istio"
    revisions = ["asm-1-28"]
  }
}

# ------------------------------- PostgreSQL --------------------------------
enable_postgres             = true
postgres_resource_group_key = "hub"

postgres = {
  name                          = "esna-qa-psql"
  administrator_login           = "pgadmin"
  sku_name                      = "B_Standard_B2s"
  postgresql_version            = "18"
  storage_mb                    = 32768
  storage_tier                  = "P4"
  zone                          = "1"
  backup_retention_days         = 7
  public_network_access_enabled = false
  delegated_subnet_key          = "app/postgres"
  private_dns_zone_key          = "postgres"
  databases = {
    app  = { name = "esna_app_qa" }
    auth = { name = "esna_auth_qa" }
  }
}

# ---------------------------------- ACR ------------------------------------
enable_acr             = true
acr_resource_group_key = "hub"

acr = {
  name          = "esnaqaappacr"
  sku           = "Standard"
  admin_enabled = false
}

# -------------------------------- Key Vault --------------------------------
enable_key_vault             = true
key_vault_resource_group_key = "hub"

key_vault = {
  name                     = "esna-qa-app-kv"
  sku_name                 = "standard"
  purge_protection_enabled = false
}

# ------------------------------ Storage account ----------------------------
enable_storage_account             = true
storage_account_resource_group_key = "hub"

storage_account = {
  name                     = "esnaqaappstg"
  account_tier             = "Standard"
  account_replication_type = "LRS"
  access_tier              = "Hot"
  is_hns_enabled           = true
  sftp_enabled             = true
  blob_soft_delete_retention_days      = 0
  container_soft_delete_retention_days = 0
}

# ------------------------------ Managed disks ------------------------------
managed_disks = {
  jumpbox_data = {
    name                 = "esna-qa-jumpbox-DataDisk_0"
    resource_group_key   = "hub"
    storage_account_type = "PremiumV2_LRS"
    create_option        = "Empty"
    disk_size_gb         = 250
    zone                 = "1"
    disk_iops_read_write = 3000
    disk_mbps_read_write = 125
    create_snapshot      = false
  }
}

# ---------------------------- Virtual machines -----------------------------
vm_admin_username = "admin-esna"
vm_ssh_public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDG28hF1o0gzH4OEa2a17b3QybgraUyWBucmRrEzactCOQzbUlW8RlgfIA/iVMhmk4mFyj8/6oJoVlOu7WyOow0gEZmJhcisZFkKL+wxcJCE4Pj2S9zpNiDu2bBo+8BGXYSf0AKGCBgY/xRJX2EC7aqbfK2pBTqJkxdzuPmFcRSWExKhvGBikKFRe0xboNWfgDTjyM9lnrBoe9UmEG3QXqplXl8CXRtVjdjYKApkiW/v26Q9DDLkVCFJoURiqsxtP1uLY3rntmW/epz80whdc05UrCIZAwCs5JKO1gWFBzc74F7/1GrlaCi1jQZup8hvik53pI0Vo+hIOe7v3Egkm9OjXhraWQ76dGXNbh0bJikS4MHYokd6qNwIkSniuK4lpTpGzED40cMLFhnbfGg5yDF9ggz9QcNJ2nyo3nQ+N2U0zc+k3/Egr30BwW+ifOEafIOJKvOaxmb+tBYdsLw9Vi/phH2XNjf+IKhXXuJLO68Ebq12O5uH3Ur36BLEQHXqh0= generated-by-azure"

virtual_machines = {
  jumpbox_win_01 = {
    name                     = "esna-qa-vm-jumpbox-01"
    resource_group_key       = "hub"
    os_type                  = "Windows"
    size                     = "Standard_D4lds_v6"
    zone                     = "1"
    subnet_key               = "app/vm"
    enable_shutdown_schedule = true
    shutdown_time            = "2000"
    shutdown_timezone        = "Central Europe Standard Time"
    os_disk                  = { storage_account_type = "Premium_LRS", disk_size_gb = 256 }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2022-datacenter-azure-edition"
    }
  }

  jumpbox_lin_01 = {
    name                     = "esna-qa-vm-jumpbox-lin01"
    resource_group_key       = "hub"
    os_type                  = "Linux"
    size                     = "Standard_D4lds_v6"
    subnet_key               = "app/vm"
    public_ip_key            = "jumpbox_lin"
    enable_shutdown_schedule = true
    shutdown_time            = "2000"
    shutdown_timezone        = "Central Europe Standard Time"
    os_disk                  = { storage_account_type = "Premium_LRS", disk_size_gb = 30 }
    source_image_reference = {
      publisher = "canonical"
      offer     = "ubuntu-24_04-lts"
      sku       = "server"
    }
  }
}
