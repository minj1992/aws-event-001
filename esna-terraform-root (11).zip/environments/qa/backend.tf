# ---------------------------------------------------------------------------
# environments/qa/backend.tf
#
# Remote state for the qa environment, in a DEDICATED storage account that
# is created by pipelines/bootstrap-backend.yml using the qa service
# connection. Each environment is fully isolated: a qa apply can only reach
# qa state.
#
# Auth at 'terraform init' time is provided by the pipeline (ARM_* env vars or
# ARM_ACCESS_KEY from the same service connection) - no secrets stored here.
# ---------------------------------------------------------------------------

terraform {
  backend "azurerm" {
    resource_group_name  = "esna-tfstate-rg-qa"
    storage_account_name = "esnatfstateqa"
    container_name       = "tfstate"
    key                  = "terraform.tfstate"
  }
}
