# ===========================================================================
# environments/prod/prod.tfvars
#
# PROD environment. Same module composition as dev/qa, but hardened and scaled:
#   - AKS Standard tier (uptime SLA), larger autoscale ceiling
#   - PostgreSQL General Purpose SKU, zone-aware, geo-redundant backups
#   - Zone-redundant ACR (Premium) with the admin user DISABLED
#   - Zone-redundant (ZRS) storage, no SFTP, public access off
#   - No auto-shutdown on VMs
#   - Non-overlapping address space (10.142.x / 10.16.x)
#
# Secrets are passed at apply time:
#   export TF_VAR_vm_admin_password='...'
#   export TF_VAR_postgres_administrator_password='...'
# ===========================================================================

# ---------------------------- Meta / identity ------------------------------
project         = "esna"
# subscription_id and tenant_id are provided at runtime from the Azure DevOps
# Library variable group (esna-<env>-secrets) via TF_VAR_subscription_id /
# TF_VAR_tenant_id - intentionally NOT hardcoded here.
environment     = "prod"
location        = "uksouth"
owner           = "platform-team"
cost_center     = "production"

extra_tags = {
  Workload   = "esna-platform"
  Criticality = "high"
}

# ---- Resource creation toggles (Terraform-side on/off) ----
enable_managed_disks    = false
enable_virtual_machines = false
# AcrPull (AKS->ACR) role assignment. Requires the pipeline SPN to have
# "User Access Administrator"/"RBAC Administrator". If it is only Contributor,
# set this to false and grant AcrPull out-of-band.
enable_acr_role_assignment = true


# ----------------------------- Resource groups -----------------------------
resource_groups = {
  hub = { name = "esna-rg-hub-prod" }
  aks = { name = "esna-rg-aks-custer-prod" }
}

network_resource_group_key = "hub"

# -------------------------------- Network ----------------------------------
virtual_networks = {
  app = {
    name          = "esna-prod-app-vnet"
    address_space = ["10.142.4.0/22"]
    subnets = {
      aks = {
        name              = "esna-prod-snet-aks"
        address_prefixes  = ["10.142.4.0/24"]
        service_endpoints = ["Microsoft.KeyVault", "Microsoft.Storage"]
        nsg_key           = "aks"
      }
      postgres = {
        name              = "esna-prod-snet-postgres"
        address_prefixes  = ["10.142.6.0/29"]
        service_endpoints = ["Microsoft.KeyVault", "Microsoft.Storage"]
        nsg_key           = "postgres"
        delegation = {
          name         = "Microsoft.DBforPostgreSQL/flexibleServers"
          service_name = "Microsoft.DBforPostgreSQL/flexibleServers"
          actions      = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
        }
      }
      bastion = {
        name             = "AzureBastionSubnet"
        address_prefixes = ["10.142.6.128/26"]
      }
      vm = {
        name              = "esna-prod-snet-vm"
        address_prefixes  = ["10.142.7.0/24"]
        service_endpoints = ["Microsoft.KeyVault", "Microsoft.Storage"]
        nat_gateway_key   = "app"
      }
    }
  }

  hub = {
    name          = "esna-vn-hub-prod"
    address_space = ["10.16.0.0/23"]
    subnets = {
      bastion = {
        name              = "AzureBastionSubnet"
        address_prefixes  = ["10.16.0.0/26"]
        service_endpoints = ["Microsoft.KeyVault"]
      }
      firewall = {
        name              = "AzureFirewallSubnet"
        address_prefixes  = ["10.16.0.128/26"]
        service_endpoints = ["Microsoft.KeyVault"]
      }
      gateway = {
        name              = "GatewaySubnet"
        address_prefixes  = ["10.16.0.192/26"]
        service_endpoints = ["Microsoft.KeyVault"]
      }
      services = {
        name              = "hub-services-subnet"
        address_prefixes  = ["10.16.0.64/26"]
        service_endpoints = ["Microsoft.KeyVault"]
        nat_gateway_key   = "hub"
      }
    }
  }
}

network_security_groups = {
  aks      = { name = "esna-prod-snet-aks-nsg" }
  postgres = { name = "esna-prod-snet-postgres-nsg" }
}

public_ips = {
  nat_app     = { name = "esna-prod-nat-pip", sku = "Standard", zones = ["1", "2", "3"] }
  nat_hub     = { name = "esna-nat-hub-prod-pip", sku = "Standard", zones = ["1", "2", "3"] }
  bastion_hub = { name = "esna-vn-hub-prod-bastion", sku = "Standard" }
}

nat_gateways = {
  app = { name = "esna-prod-app-nat", sku_name = "Standard", public_ip_key = "nat_app", zones = ["1", "2", "3"] }
  hub = { name = "esna-nat-hub-prod", sku_name = "Standard", public_ip_key = "nat_hub", zones = ["1", "2", "3"] }
}

bastion = {
  name          = "esna-vn-hub-prod-Bastion"
  sku           = "Standard"
  scale_units   = 2
  vnet_key      = "hub"
  subnet_key    = "bastion"
  public_ip_key = "bastion_hub"
}

peerings = {
  hub_to_app = {
    name            = "peer-hub-to-prod"
    local_vnet_key  = "hub"
    remote_vnet_key = "app"
  }
  app_to_hub = {
    name            = "peer-prod-to-hub"
    local_vnet_key  = "app"
    remote_vnet_key = "hub"
  }
}

private_dns_zones = {
  postgres = {
    name = "privatelink.postgres.database.azure.com"
    vnet_links = {
      app = { name = "esna-prod-app-vnet-link", vnet_key = "app" }
      hub = { name = "esna-prod-hub-vnet-link", vnet_key = "hub" }
    }
  }
}

# ---------------------------------- AKS ------------------------------------
enable_aks             = true
aks_resource_group_key = "aks"

aks = {
  name               = "esna-aks-prod"
  dns_prefix         = "esna-aks-prod-dns"
  kubernetes_version = "1.34.7"
  sku_tier           = "Standard"
  node_subnet_key    = "app/aks"

  default_node_pool = {
    name            = "agentpool"
    vm_size         = "Standard_D4pds_v6"
    auto_scaling    = true
    node_count      = 3
    min_count       = 3
    max_count       = 6
    max_pods        = 110
    os_disk_size_gb = 220
    os_disk_type    = "Ephemeral"
    os_sku          = "Ubuntu"
    node_labels     = { app = "esnaprod", env = "prod", workload = "esnaapi" }
    zones           = ["1", "2", "3"]
  }

  network_profile = {
    network_plugin      = "azure"
    network_plugin_mode = "overlay"
    dns_service_ip      = "10.0.0.10"
    service_cidr        = "10.0.0.0/16"
    pod_cidr            = "10.244.0.0/16"
  }

  service_mesh = {
    mode      = "Istio"
    revisions = ["asm-1-28"]
  }
}

# ------------------------------- PostgreSQL --------------------------------
enable_postgres             = true
postgres_resource_group_key = "hub"

postgres = {
  name                          = "esna-prod-psql"
  administrator_login           = "pgadmin"
  sku_name                      = "GP_Standard_D2s_v3"
  postgresql_version            = "18"
  storage_mb                    = 131072
  storage_tier                  = "P10"
  zone                          = "1"
  backup_retention_days         = 35
  geo_redundant_backup_enabled  = true
  public_network_access_enabled = false
  delegated_subnet_key          = "app/postgres"
  private_dns_zone_key          = "postgres"
  databases = {
    app  = { name = "esna_app_prod" }
    auth = { name = "esna_auth_prod" }
  }
}

# ---------------------------------- ACR ------------------------------------
enable_acr             = true
acr_resource_group_key = "hub"

acr = {
  name                    = "esnaprodappacr"
  sku                     = "Premium"
  admin_enabled           = false
  zone_redundancy_enabled = true
}

# -------------------------------- Key Vault --------------------------------
enable_key_vault             = true
key_vault_resource_group_key = "hub"

key_vault = {
  name                          = "esna-prod-app-kv"
  sku_name                      = "standard"
  purge_protection_enabled      = false
  public_network_access_enabled = false
}

# ------------------------------ Storage account ----------------------------
enable_storage_account             = true
storage_account_resource_group_key = "hub"

storage_account = {
  name                          = "esnaprodappstg"
  account_tier                  = "Standard"
  account_replication_type      = "ZRS"
  access_tier                   = "Hot"
  is_hns_enabled                = true
  sftp_enabled                  = false
  public_network_access_enabled = false
}

# ------------------------------ Managed disks ------------------------------
managed_disks = {}

# ---------------------------- Virtual machines -----------------------------
vm_admin_username = "admin-esna"
vm_ssh_public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDG28hF1o0gzH4OEa2a17b3QybgraUyWBucmRrEzactCOQzbUlW8RlgfIA/iVMhmk4mFyj8/6oJoVlOu7WyOow0gEZmJhcisZFkKL+wxcJCE4Pj2S9zpNiDu2bBo+8BGXYSf0AKGCBgY/xRJX2EC7aqbfK2pBTqJkxdzuPmFcRSWExKhvGBikKFRe0xboNWfgDTjyM9lnrBoe9UmEG3QXqplXl8CXRtVjdjYKApkiW/v26Q9DDLkVCFJoURiqsxtP1uLY3rntmW/epz80whdc05UrCIZAwCs5JKO1gWFBzc74F7/1GrlaCi1jQZup8hvik53pI0Vo+hIOe7v3Egkm9OjXhraWQ76dGXNbh0bJikS4MHYokd6qNwIkSniuK4lpTpGzED40cMLFhnbfGg5yDF9ggz9QcNJ2nyo3nQ+N2U0zc+k3/Egr30BwW+ifOEafIOJKvOaxmb+tBYdsLw9Vi/phH2XNjf+IKhXXuJLO68Ebq12O5uH3Ur36BLEQHXqh0= generated-by-azure"

virtual_machines = {
  jumpbox_win_01 = {
    name               = "esna-prod-vm-jumpbox-01"
    resource_group_key = "hub"
    os_type            = "Windows"
    size               = "Standard_D4lds_v6"
    zone               = "1"
    subnet_key         = "app/vm"
    os_disk            = { storage_account_type = "Premium_LRS", disk_size_gb = 256 }
    source_image_reference = {
      publisher = "MicrosoftWindowsServer"
      offer     = "WindowsServer"
      sku       = "2022-datacenter-azure-edition"
    }
  }
}
