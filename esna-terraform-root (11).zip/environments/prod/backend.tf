# ---------------------------------------------------------------------------
# environments/prod/backend.tf
#
# Remote state for the prod environment, in a DEDICATED storage account that
# is created by pipelines/bootstrap-backend.yml using the prod service
# connection. Each environment is fully isolated: a prod apply can only reach
# prod state.
#
# Auth at 'terraform init' time is provided by the pipeline (ARM_* env vars or
# ARM_ACCESS_KEY from the same service connection) - no secrets stored here.
# ---------------------------------------------------------------------------

terraform {
  backend "azurerm" {
    resource_group_name  = "esna-tfstate-rg-prod"
    storage_account_name = "esnatfstateprod"
    container_name       = "tfstate"
    key                  = "terraform.tfstate"
  }
}
