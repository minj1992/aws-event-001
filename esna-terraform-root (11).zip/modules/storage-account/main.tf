# ---------------------------------------------------------------------------
# storage-account
# Creates an Azure Storage account (StorageV2) with optional ADLS Gen2 (HNS),
# SFTP and network rules.
# ---------------------------------------------------------------------------

resource "azurerm_storage_account" "this" {
  name                          = var.name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  account_tier                  = var.account_tier
  account_replication_type      = var.account_replication_type
  account_kind                  = var.account_kind
  access_tier                   = var.access_tier
  is_hns_enabled                = var.is_hns_enabled
  sftp_enabled                  = var.sftp_enabled
  min_tls_version               = var.min_tls_version
  https_traffic_only_enabled    = true
  public_network_access_enabled = var.public_network_access_enabled
  tags                          = var.tags

  blob_properties {
    dynamic "delete_retention_policy" {
      for_each = var.blob_soft_delete_retention_days > 0 ? [var.blob_soft_delete_retention_days] : []
      content {
        days = delete_retention_policy.value
      }
    }
    dynamic "container_delete_retention_policy" {
      for_each = var.container_soft_delete_retention_days > 0 ? [var.container_soft_delete_retention_days] : []
      content {
        days = container_delete_retention_policy.value
      }
    }
  }

  dynamic "network_rules" {
    for_each = var.network_rules == null ? [] : [var.network_rules]
    content {
      bypass                     = network_rules.value.bypass
      default_action             = network_rules.value.default_action
      ip_rules                   = network_rules.value.ip_rules
      virtual_network_subnet_ids = network_rules.value.virtual_network_subnet_ids
    }
  }
}
