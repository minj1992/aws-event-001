variable "name" {
  description = "Storage account name (globally unique, 3-24 lowercase alphanumeric)."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}

variable "account_tier" {
  description = "Storage account tier (Standard or Premium)."
  type        = string
  default     = "Standard"
}

variable "account_replication_type" {
  description = "Replication type (LRS, GRS, ZRS, RAGRS, GZRS)."
  type        = string
  default     = "LRS"
}

variable "account_kind" {
  description = "Account kind (StorageV2, BlobStorage, etc.)."
  type        = string
  default     = "StorageV2"
}

variable "access_tier" {
  description = "Blob access tier (Hot or Cool)."
  type        = string
  default     = "Hot"
}

variable "is_hns_enabled" {
  description = "Enable hierarchical namespace (ADLS Gen2)."
  type        = bool
  default     = false
}

variable "sftp_enabled" {
  description = "Enable SFTP (requires is_hns_enabled = true)."
  type        = bool
  default     = false
}

variable "min_tls_version" {
  description = "Minimum TLS version."
  type        = string
  default     = "TLS1_2"
}

variable "public_network_access_enabled" {
  description = "Whether public network access is enabled."
  type        = bool
  default     = true
}

variable "blob_soft_delete_retention_days" {
  description = "Blob soft-delete retention in days. Set to 0 to DISABLE blob soft-delete (clean teardown)."
  type        = number
  default     = 7
}

variable "container_soft_delete_retention_days" {
  description = "Container soft-delete retention in days. Set to 0 to DISABLE container soft-delete."
  type        = number
  default     = 7
}

variable "network_rules" {
  description = "Optional network rule set."
  type = object({
    bypass                     = optional(list(string), ["AzureServices"])
    default_action             = optional(string, "Deny")
    ip_rules                   = optional(list(string), [])
    virtual_network_subnet_ids = optional(list(string), [])
  })
  default = null
}

variable "tags" {
  description = "Tags applied to the storage account."
  type        = map(string)
  default     = {}
}
