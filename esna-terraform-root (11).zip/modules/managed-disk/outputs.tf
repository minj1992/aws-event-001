output "id" {
  description = "Managed disk ID."
  value       = azurerm_managed_disk.this.id
}

output "name" {
  description = "Managed disk name."
  value       = azurerm_managed_disk.this.name
}

output "snapshot_id" {
  description = "Snapshot ID (null if not created)."
  value       = try(azurerm_snapshot.this[0].id, null)
}
