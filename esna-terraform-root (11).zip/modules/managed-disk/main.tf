# ---------------------------------------------------------------------------
# managed-disk
# Creates a standalone Azure managed disk and, optionally, a snapshot of it.
# ---------------------------------------------------------------------------

resource "azurerm_managed_disk" "this" {
  name                 = var.name
  location             = var.location
  resource_group_name  = var.resource_group_name
  storage_account_type = var.storage_account_type
  create_option        = var.create_option
  disk_size_gb         = var.disk_size_gb
  zone                 = var.zone
  disk_iops_read_write = var.disk_iops_read_write
  disk_mbps_read_write = var.disk_mbps_read_write
  tags                 = var.tags
}

resource "azurerm_snapshot" "this" {
  count = var.create_snapshot ? 1 : 0

  name                = coalesce(var.snapshot_name, "${var.name}-snapshot")
  location            = var.location
  resource_group_name = var.resource_group_name
  create_option       = "Copy"
  source_resource_id  = azurerm_managed_disk.this.id
  incremental_enabled = true
  tags                = var.tags
}
