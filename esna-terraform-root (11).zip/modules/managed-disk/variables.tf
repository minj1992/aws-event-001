variable "name" {
  description = "Managed disk name."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}

variable "storage_account_type" {
  description = "Disk SKU (e.g. Premium_LRS, PremiumV2_LRS, StandardSSD_LRS)."
  type        = string
  default     = "Premium_LRS"
}

variable "create_option" {
  description = "Disk create option (Empty, Copy, Import, etc.)."
  type        = string
  default     = "Empty"
}

variable "disk_size_gb" {
  description = "Disk size in GB."
  type        = number
}

variable "zone" {
  description = "Availability zone, or null."
  type        = string
  default     = null
}

variable "disk_iops_read_write" {
  description = "Provisioned IOPS (PremiumV2/UltraSSD only)."
  type        = number
  default     = null
}

variable "disk_mbps_read_write" {
  description = "Provisioned throughput in MB/s (PremiumV2/UltraSSD only)."
  type        = number
  default     = null
}

variable "create_snapshot" {
  description = "Whether to create an incremental snapshot of the disk."
  type        = bool
  default     = false
}

variable "snapshot_name" {
  description = "Snapshot name (used when create_snapshot is true)."
  type        = string
  default     = null
}

variable "tags" {
  description = "Tags applied to the disk and snapshot."
  type        = map(string)
  default     = {}
}
