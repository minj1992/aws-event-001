# ---------------------------------------------------------------------------
# resource-group
# Creates a single Azure Resource Group.
# ---------------------------------------------------------------------------

resource "azurerm_resource_group" "this" {
  name     = var.name
  location = var.location
  tags     = var.tags
}
