# ---------------------------------------------------------------------------
# aks
# Creates a user-assigned identity (when none is supplied) and an AKS cluster
# with a system node pool, Azure CNI overlay networking, OIDC / workload
# identity, Azure RBAC and (optionally) the Istio service mesh + monitoring.
# ---------------------------------------------------------------------------

locals {
  create_uami     = length(var.identity_ids) == 0
  identity_ids    = local.create_uami ? [azurerm_user_assigned_identity.this[0].id] : var.identity_ids
}

resource "azurerm_user_assigned_identity" "this" {
  count = local.create_uami ? 1 : 0

  name                = "${var.name}-uami"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_kubernetes_cluster" "this" {
  name                              = var.name
  location                          = var.location
  resource_group_name               = var.resource_group_name
  dns_prefix                        = var.dns_prefix
  kubernetes_version                = var.kubernetes_version
  sku_tier                          = var.sku_tier
  node_resource_group               = var.node_resource_group
  oidc_issuer_enabled               = var.oidc_issuer_enabled
  workload_identity_enabled         = var.workload_identity_enabled
  azure_policy_enabled              = var.azure_policy_enabled
  role_based_access_control_enabled = true
  tags                              = var.tags

  default_node_pool {
    name                 = var.default_node_pool.name
    vm_size              = var.default_node_pool.vm_size
    auto_scaling_enabled = var.default_node_pool.auto_scaling
    node_count           = var.default_node_pool.node_count
    min_count            = var.default_node_pool.auto_scaling ? var.default_node_pool.min_count : null
    max_count            = var.default_node_pool.auto_scaling ? var.default_node_pool.max_count : null
    max_pods             = var.default_node_pool.max_pods
    os_disk_size_gb      = var.default_node_pool.os_disk_size_gb
    os_disk_type         = var.default_node_pool.os_disk_type
    os_sku               = var.default_node_pool.os_sku
    vnet_subnet_id       = var.default_node_pool.vnet_subnet_id
    node_labels          = var.default_node_pool.node_labels
    zones                = var.default_node_pool.zones
  }

  identity {
    type         = "UserAssigned"
    identity_ids = local.identity_ids
  }

  azure_active_directory_role_based_access_control {
    tenant_id              = var.tenant_id
    azure_rbac_enabled     = var.azure_rbac_enabled
    admin_group_object_ids = var.admin_group_object_ids
  }

  network_profile {
    network_plugin      = var.network_profile.network_plugin
    network_plugin_mode = var.network_profile.network_plugin_mode
    network_policy      = var.network_profile.network_policy
    load_balancer_sku   = var.network_profile.load_balancer_sku
    outbound_type       = var.network_profile.outbound_type
    dns_service_ip      = var.network_profile.dns_service_ip
    service_cidr        = var.network_profile.service_cidr
    pod_cidr            = var.network_profile.pod_cidr
  }

  dynamic "oms_agent" {
    for_each = var.log_analytics_workspace_id == null ? [] : [var.log_analytics_workspace_id]
    content {
      log_analytics_workspace_id      = oms_agent.value
      msi_auth_for_monitoring_enabled = true
    }
  }

  dynamic "service_mesh_profile" {
    for_each = var.service_mesh == null ? [] : [var.service_mesh]
    content {
      mode                             = service_mesh_profile.value.mode
      revisions                        = service_mesh_profile.value.revisions
      internal_ingress_gateway_enabled = service_mesh_profile.value.internal_ingress_gateway_enabled
      external_ingress_gateway_enabled = service_mesh_profile.value.external_ingress_gateway_enabled
    }
  }

  lifecycle {
    ignore_changes = [kubernetes_version]
  }
}
