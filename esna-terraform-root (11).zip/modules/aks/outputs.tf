output "id" {
  description = "AKS cluster ID."
  value       = azurerm_kubernetes_cluster.this.id
}

output "name" {
  description = "AKS cluster name."
  value       = azurerm_kubernetes_cluster.this.name
}

output "oidc_issuer_url" {
  description = "OIDC issuer URL (for workload identity federation)."
  value       = azurerm_kubernetes_cluster.this.oidc_issuer_url
}

output "node_resource_group" {
  description = "The auto-generated node resource group name."
  value       = azurerm_kubernetes_cluster.this.node_resource_group
}

output "identity_id" {
  description = "User-assigned identity ID used by the cluster."
  value       = local.identity_ids[0]
}

output "kubelet_identity_object_id" {
  description = "Object ID of the kubelet (node) identity - used to grant AcrPull on the registry."
  value       = azurerm_kubernetes_cluster.this.kubelet_identity[0].object_id
}
