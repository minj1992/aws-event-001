variable "name" {
  description = "AKS cluster name."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}

variable "dns_prefix" {
  description = "DNS prefix for the cluster API server."
  type        = string
}

variable "kubernetes_version" {
  description = "Kubernetes version."
  type        = string
  default     = "1.34.7"
}

variable "sku_tier" {
  description = "Cluster SKU tier (Free, Standard, Premium)."
  type        = string
  default     = "Free"
}

variable "node_resource_group" {
  description = "Name of the auto-generated node resource group. Null lets Azure choose."
  type        = string
  default     = null
}

variable "default_node_pool" {
  description = "Default (system) node pool configuration."
  type = object({
    name                = optional(string, "agentpool")
    vm_size             = optional(string, "Standard_D4pds_v6")
    auto_scaling        = optional(bool, true)
    node_count          = optional(number, 2)
    min_count           = optional(number, 2)
    max_count           = optional(number, 3)
    max_pods            = optional(number, 110)
    os_disk_size_gb     = optional(number, 128)
    os_disk_type        = optional(string, "Managed")
    os_sku              = optional(string, "Ubuntu")
    vnet_subnet_id      = optional(string)
    node_labels         = optional(map(string), {})
    zones               = optional(list(string), [])
  })
}

variable "network_profile" {
  description = "Cluster networking configuration."
  type = object({
    network_plugin      = optional(string, "azure")
    network_plugin_mode = optional(string, "overlay")
    network_policy      = optional(string)
    load_balancer_sku   = optional(string, "standard")
    outbound_type       = optional(string, "loadBalancer")
    dns_service_ip      = optional(string, "10.0.0.10")
    service_cidr        = optional(string, "10.0.0.0/16")
    pod_cidr            = optional(string, "10.244.0.0/16")
  })
  default = {}
}

variable "identity_ids" {
  description = "User-assigned identity IDs. If empty, a SystemAssigned identity is used."
  type        = list(string)
  default     = []
}

variable "oidc_issuer_enabled" {
  description = "Enable the OIDC issuer (required for workload identity)."
  type        = bool
  default     = true
}

variable "workload_identity_enabled" {
  description = "Enable Azure AD workload identity."
  type        = bool
  default     = true
}

variable "azure_policy_enabled" {
  description = "Enable the Azure Policy add-on."
  type        = bool
  default     = true
}

variable "azure_rbac_enabled" {
  description = "Enable Azure RBAC for Kubernetes authorization."
  type        = bool
  default     = true
}

variable "log_analytics_workspace_id" {
  description = "Log Analytics workspace ID for the OMS agent. Null disables it."
  type        = string
  default     = null
}

variable "service_mesh" {
  description = "Optional Istio service mesh profile. Null disables it."
  type = object({
    mode                             = optional(string, "Istio")
    revisions                        = optional(list(string), ["asm-1-28"])
    internal_ingress_gateway_enabled = optional(bool, true)
    external_ingress_gateway_enabled = optional(bool, true)
  })
  default = null
}

variable "tenant_id" {
  description = "Microsoft Entra ID (Azure AD) tenant ID for Azure AD RBAC. Null uses the subscription's tenant."
  type        = string
  default     = null
}

variable "admin_group_object_ids" {
  description = "Entra ID group object IDs granted cluster-admin via Azure AD RBAC."
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags applied to the cluster."
  type        = map(string)
  default     = {}
}
