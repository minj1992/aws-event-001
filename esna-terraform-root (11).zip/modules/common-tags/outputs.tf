output "tags" {
  description = "Canonical tag map to apply to all resources."
  value       = local.tags
}
