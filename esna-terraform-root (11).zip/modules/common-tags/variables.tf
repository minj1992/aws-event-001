variable "project" {
  description = "Project / application short name (e.g. esna)."
  type        = string
}

variable "environment" {
  description = "Deployment environment (dev, qa, prod)."
  type        = string
}

variable "owner" {
  description = "Team or person responsible for the resources."
  type        = string
  default     = "platform-team"
}

variable "cost_center" {
  description = "Cost center used for billing/showback."
  type        = string
  default     = "engineering"
}

variable "managed_by" {
  description = "Tooling that manages the resources."
  type        = string
  default     = "terraform"
}

variable "extra_tags" {
  description = "Additional free-form tags merged on top of the standard set."
  type        = map(string)
  default     = {}
}
