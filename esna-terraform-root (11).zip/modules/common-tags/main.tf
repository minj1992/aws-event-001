# ---------------------------------------------------------------------------
# common-tags
# A tiny helper module with no resources. It builds one canonical tag map so
# every environment and module tags resources identically.
# ---------------------------------------------------------------------------

locals {
  standard_tags = {
    Project     = var.project
    Environment = var.environment
    Owner       = var.owner
    CostCenter  = var.cost_center
    ManagedBy   = var.managed_by
  }

  tags = merge(local.standard_tags, var.extra_tags)
}
