# ---------------------------------------------------------------------------
# acr
# Creates an Azure Container Registry.
#
# Note: the default scope maps (_repositories_pull, _repositories_push, etc.)
# are created automatically by the Azure platform; they are intentionally NOT
# managed here. Define custom scope maps / tokens at the environment layer if
# fine-grained access control is required.
# ---------------------------------------------------------------------------

resource "azurerm_container_registry" "this" {
  name                          = var.name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  sku                           = var.sku
  admin_enabled                 = var.admin_enabled
  public_network_access_enabled = var.public_network_access_enabled
  zone_redundancy_enabled       = var.zone_redundancy_enabled
  tags                          = var.tags
}
