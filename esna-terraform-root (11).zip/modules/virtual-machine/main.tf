# ---------------------------------------------------------------------------
# virtual-machine
# Creates one Linux OR Windows VM, its network interface, and (optionally) a
# daily auto-shutdown schedule. Designed to be instantiated once per VM.
# ---------------------------------------------------------------------------

locals {
  is_windows = var.os_type == "Windows"
  is_linux   = var.os_type == "Linux"
}

resource "azurerm_network_interface" "this" {
  name                = "${var.name}-nic"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  ip_configuration {
    name                          = "ipconfig"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = var.private_ip_address_allocation
    public_ip_address_id          = var.public_ip_id
  }
}

# -----------------------------------------------------------------------------
# Windows VM
# -----------------------------------------------------------------------------
resource "azurerm_windows_virtual_machine" "this" {
  count = local.is_windows ? 1 : 0

  name                  = var.name
  location              = var.location
  resource_group_name   = var.resource_group_name
  size                  = var.size
  zone                  = var.zone
  admin_username        = var.admin_username
  admin_password        = var.admin_password
  network_interface_ids = [azurerm_network_interface.this.id]
  secure_boot_enabled   = true
  vtpm_enabled          = true
  tags                  = var.tags

  os_disk {
    caching              = var.os_disk.caching
    storage_account_type = var.os_disk.storage_account_type
    disk_size_gb         = var.os_disk.disk_size_gb
  }

  source_image_reference {
    publisher = var.source_image_reference.publisher
    offer     = var.source_image_reference.offer
    sku       = var.source_image_reference.sku
    version   = var.source_image_reference.version
  }

  identity {
    type = "SystemAssigned"
  }
}

# -----------------------------------------------------------------------------
# Linux VM
# -----------------------------------------------------------------------------
resource "azurerm_linux_virtual_machine" "this" {
  count = local.is_linux ? 1 : 0

  name                            = var.name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  size                            = var.size
  zone                            = var.zone
  admin_username                  = var.admin_username
  admin_password                  = var.admin_password
  disable_password_authentication = var.ssh_public_key != null
  network_interface_ids           = [azurerm_network_interface.this.id]
  secure_boot_enabled             = true
  vtpm_enabled                    = true
  tags                            = var.tags

  dynamic "admin_ssh_key" {
    for_each = var.ssh_public_key == null ? [] : [var.ssh_public_key]
    content {
      username   = var.admin_username
      public_key = admin_ssh_key.value
    }
  }

  os_disk {
    caching              = var.os_disk.caching
    storage_account_type = var.os_disk.storage_account_type
    disk_size_gb         = var.os_disk.disk_size_gb
  }

  source_image_reference {
    publisher = var.source_image_reference.publisher
    offer     = var.source_image_reference.offer
    sku       = var.source_image_reference.sku
    version   = var.source_image_reference.version
  }

  identity {
    type = "SystemAssigned"
  }
}

locals {
  vm_id = local.is_windows ? azurerm_windows_virtual_machine.this[0].id : azurerm_linux_virtual_machine.this[0].id
}

# -----------------------------------------------------------------------------
# Optional auto-shutdown schedule (cost control for non-prod jumpboxes)
# -----------------------------------------------------------------------------
resource "azurerm_dev_test_global_vm_shutdown_schedule" "this" {
  count = var.enable_shutdown_schedule ? 1 : 0

  virtual_machine_id    = local.vm_id
  location              = var.location
  enabled               = true
  daily_recurrence_time = var.shutdown_time
  timezone              = var.shutdown_timezone
  tags                  = var.tags

  notification_settings {
    enabled = false
  }
}
