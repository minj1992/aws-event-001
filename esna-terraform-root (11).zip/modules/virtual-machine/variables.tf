variable "name" {
  description = "Virtual machine name."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}

variable "os_type" {
  description = "Operating system type: \"Linux\" or \"Windows\"."
  type        = string
  validation {
    condition     = contains(["Linux", "Windows"], var.os_type)
    error_message = "os_type must be either \"Linux\" or \"Windows\"."
  }
}

variable "size" {
  description = "VM size / SKU (e.g. Standard_D4lds_v6)."
  type        = string
}

variable "zone" {
  description = "Availability zone (e.g. \"1\"), or null for none."
  type        = string
  default     = null
}

variable "subnet_id" {
  description = "Subnet ID the VM NIC attaches to."
  type        = string
}

variable "private_ip_address_allocation" {
  description = "Private IP allocation method (Dynamic/Static)."
  type        = string
  default     = "Dynamic"
}

variable "public_ip_id" {
  description = "Optional public IP ID to associate with the NIC."
  type        = string
  default     = null
}

variable "admin_username" {
  description = "Administrator username."
  type        = string
}

variable "admin_password" {
  description = "Administrator password (required for Windows; optional for Linux)."
  type        = string
  default     = null
  sensitive   = true
}

variable "ssh_public_key" {
  description = "SSH public key for Linux VMs."
  type        = string
  default     = null
}

variable "os_disk" {
  description = "OS disk settings."
  type = object({
    caching              = optional(string, "ReadWrite")
    storage_account_type = optional(string, "Premium_LRS")
    disk_size_gb         = optional(number)
  })
  default = {}
}

variable "source_image_reference" {
  description = "Marketplace image reference."
  type = object({
    publisher = string
    offer     = string
    sku       = string
    version   = optional(string, "latest")
  })
}

variable "enable_shutdown_schedule" {
  description = "Whether to create an auto-shutdown schedule for the VM."
  type        = bool
  default     = false
}

variable "shutdown_time" {
  description = "Daily shutdown time in HHmm (24h) format."
  type        = string
  default     = "2000"
}

variable "shutdown_timezone" {
  description = "Timezone for the shutdown schedule."
  type        = string
  default     = "UTC"
}

variable "tags" {
  description = "Tags applied to all VM resources."
  type        = map(string)
  default     = {}
}
