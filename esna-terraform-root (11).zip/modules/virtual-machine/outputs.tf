output "id" {
  description = "Virtual machine ID."
  value       = local.vm_id
}

output "name" {
  description = "Virtual machine name."
  value       = var.name
}

output "nic_id" {
  description = "Network interface ID."
  value       = azurerm_network_interface.this.id
}

output "private_ip_address" {
  description = "Private IP address of the primary NIC."
  value       = azurerm_network_interface.this.private_ip_address
}
