# ---------------------------------------------------------------------------
# postgres
# Creates an Azure Database for PostgreSQL Flexible Server, its databases, and
# any explicit server parameter overrides.
#
# The hundreds of azurerm_postgresql_flexible_server_configuration resources in
# a brand-new server are Azure-managed defaults and are intentionally NOT
# modelled here. Pass only the parameters you actually want to change via the
# `configurations` map (e.g. { "max_connections" = "200" }).
# ---------------------------------------------------------------------------

resource "azurerm_postgresql_flexible_server" "this" {
  name                          = var.name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  administrator_login           = var.administrator_login
  administrator_password        = var.administrator_password
  sku_name                      = var.sku_name
  version                       = var.postgresql_version
  storage_mb                    = var.storage_mb
  storage_tier                  = var.storage_tier
  zone                          = var.zone
  backup_retention_days         = var.backup_retention_days
  geo_redundant_backup_enabled  = var.geo_redundant_backup_enabled
  auto_grow_enabled             = var.auto_grow_enabled
  public_network_access_enabled = var.public_network_access_enabled
  delegated_subnet_id           = var.delegated_subnet_id
  private_dns_zone_id           = var.private_dns_zone_id
  tags                          = var.tags

  authentication {
    password_auth_enabled         = true
    active_directory_auth_enabled = false
  }

  lifecycle {
    # Password rotation is handled out-of-band (e.g. via Key Vault).
    ignore_changes = [zone]
  }
}

resource "azurerm_postgresql_flexible_server_database" "this" {
  for_each = var.databases

  name      = each.value.name
  server_id = azurerm_postgresql_flexible_server.this.id
  charset   = each.value.charset
  collation = each.value.collation
}

resource "azurerm_postgresql_flexible_server_configuration" "this" {
  for_each = var.configurations

  name      = each.key
  server_id = azurerm_postgresql_flexible_server.this.id
  value     = each.value
}
