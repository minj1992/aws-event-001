variable "name" {
  description = "PostgreSQL Flexible Server name."
  type        = string
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}

variable "administrator_login" {
  description = "Administrator login name."
  type        = string
  default     = "pgadmin"
}

variable "administrator_password" {
  description = "Administrator password."
  type        = string
  sensitive   = true
}

variable "sku_name" {
  description = "Compute SKU (e.g. B_Standard_B2s, GP_Standard_D2s_v3)."
  type        = string
  default     = "B_Standard_B2s"
}

variable "postgresql_version" {
  description = "PostgreSQL major version."
  type        = string
  default     = "18"
}

variable "storage_mb" {
  description = "Storage size in MB."
  type        = number
  default     = 32768
}

variable "storage_tier" {
  description = "Storage performance tier (e.g. P4, P10)."
  type        = string
  default     = "P4"
}

variable "zone" {
  description = "Availability zone."
  type        = string
  default     = "1"
}

variable "backup_retention_days" {
  description = "Backup retention in days (7-35)."
  type        = number
  default     = 7
}

variable "geo_redundant_backup_enabled" {
  description = "Whether geo-redundant backups are enabled."
  type        = bool
  default     = false
}

variable "auto_grow_enabled" {
  description = "Whether storage auto-grow is enabled."
  type        = bool
  default     = false
}

variable "public_network_access_enabled" {
  description = "Whether public network access is enabled."
  type        = bool
  default     = false
}

variable "delegated_subnet_id" {
  description = "Delegated subnet ID for private (VNet-integrated) access. Null for public."
  type        = string
  default     = null
}

variable "private_dns_zone_id" {
  description = "Private DNS zone ID for VNet integration. Null for public."
  type        = string
  default     = null
}

variable "databases" {
  description = "Map of databases to create (keyed by logical name)."
  type = map(object({
    name      = string
    charset   = optional(string, "UTF8")
    collation = optional(string, "en_US.utf8")
  }))
  default = {}
}

variable "configurations" {
  description = "Map of non-default server parameter overrides (name => value)."
  type        = map(string)
  default     = {}
}

variable "tags" {
  description = "Tags applied to the server."
  type        = map(string)
  default     = {}
}
