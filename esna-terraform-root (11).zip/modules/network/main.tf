# ---------------------------------------------------------------------------
# network
# Builds VNets, subnets, NSGs (+rules), subnet/NSG associations, public IPs,
# NAT gateways (+associations), an optional Bastion host, VNet peerings and
# private DNS zones (with VNet links).
#
# All inter-resource references use logical map keys so an environment can
# describe its whole network topology purely from tfvars.
# ---------------------------------------------------------------------------

locals {
  # Flatten "vnet -> subnet" into a single map keyed "<vnet_key>/<subnet_key>"
  subnets = merge([
    for vnet_key, vnet in var.virtual_networks : {
      for subnet_key, subnet in vnet.subnets :
      "${vnet_key}/${subnet_key}" => merge(subnet, {
        vnet_key   = vnet_key
        subnet_key = subnet_key
      })
    }
  ]...)

  # Subnets that have an NSG association requested
  subnet_nsg_assoc = {
    for k, s in local.subnets : k => s if s.nsg_key != null
  }

  # Subnets that have a NAT gateway association requested
  subnet_nat_assoc = {
    for k, s in local.subnets : k => s if s.nat_gateway_key != null
  }
}

# -----------------------------------------------------------------------------
# Virtual networks
# -----------------------------------------------------------------------------
resource "azurerm_virtual_network" "this" {
  for_each = var.virtual_networks

  name                = each.value.name
  address_space       = each.value.address_space
  dns_servers         = each.value.dns_servers
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

# -----------------------------------------------------------------------------
# Subnets
# -----------------------------------------------------------------------------
resource "azurerm_subnet" "this" {
  for_each = local.subnets

  name                              = each.value.name
  resource_group_name               = var.resource_group_name
  virtual_network_name              = azurerm_virtual_network.this[each.value.vnet_key].name
  address_prefixes                  = each.value.address_prefixes
  service_endpoints                 = each.value.service_endpoints
  private_endpoint_network_policies = each.value.private_endpoint_network_policies

  dynamic "delegation" {
    for_each = each.value.delegation == null ? [] : [each.value.delegation]
    content {
      name = delegation.value.name
      service_delegation {
        name    = delegation.value.service_name
        actions = delegation.value.actions
      }
    }
  }
}

# -----------------------------------------------------------------------------
# Network security groups
# -----------------------------------------------------------------------------
resource "azurerm_network_security_group" "this" {
  for_each = var.network_security_groups

  name                = each.value.name
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_network_security_rule" "this" {
  for_each = merge([
    for nsg_key, nsg in var.network_security_groups : {
      for rule in nsg.rules :
      "${nsg_key}/${rule.name}" => merge(rule, { nsg_key = nsg_key })
    }
  ]...)

  name                        = each.value.name
  priority                    = each.value.priority
  direction                   = each.value.direction
  access                      = each.value.access
  protocol                    = each.value.protocol
  source_port_range           = each.value.source_port_range
  destination_port_range      = each.value.destination_port_range
  source_address_prefix       = each.value.source_address_prefix
  destination_address_prefix  = each.value.destination_address_prefix
  resource_group_name         = var.resource_group_name
  network_security_group_name = azurerm_network_security_group.this[each.value.nsg_key].name
}

resource "azurerm_subnet_network_security_group_association" "this" {
  for_each = local.subnet_nsg_assoc

  subnet_id                 = azurerm_subnet.this[each.key].id
  network_security_group_id = azurerm_network_security_group.this[each.value.nsg_key].id
}

# -----------------------------------------------------------------------------
# Public IPs
# -----------------------------------------------------------------------------
resource "azurerm_public_ip" "this" {
  for_each = var.public_ips

  name                = each.value.name
  location            = var.location
  resource_group_name = var.resource_group_name
  allocation_method   = each.value.allocation_method
  sku                 = each.value.sku
  zones               = each.value.zones
  tags                = var.tags
}

# -----------------------------------------------------------------------------
# NAT gateways
# -----------------------------------------------------------------------------
resource "azurerm_nat_gateway" "this" {
  for_each = var.nat_gateways

  name                    = each.value.name
  location                = var.location
  resource_group_name     = var.resource_group_name
  sku_name                = each.value.sku_name
  idle_timeout_in_minutes = each.value.idle_timeout_in_minutes
  tags                    = var.tags
}

resource "azurerm_nat_gateway_public_ip_association" "this" {
  for_each = var.nat_gateways

  nat_gateway_id       = azurerm_nat_gateway.this[each.key].id
  public_ip_address_id = azurerm_public_ip.this[each.value.public_ip_key].id
}

resource "azurerm_subnet_nat_gateway_association" "this" {
  for_each = local.subnet_nat_assoc

  subnet_id      = azurerm_subnet.this[each.key].id
  nat_gateway_id = azurerm_nat_gateway.this[each.value.nat_gateway_key].id
}

# -----------------------------------------------------------------------------
# Bastion host
# -----------------------------------------------------------------------------
resource "azurerm_bastion_host" "this" {
  count = var.bastion == null ? 0 : 1

  name                = var.bastion.name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = var.bastion.sku
  scale_units         = var.bastion.scale_units
  tags                = var.tags

  ip_configuration {
    name                 = "IpConf"
    subnet_id            = azurerm_subnet.this["${var.bastion.vnet_key}/${var.bastion.subnet_key}"].id
    public_ip_address_id = azurerm_public_ip.this[var.bastion.public_ip_key].id
  }
}

# -----------------------------------------------------------------------------
# VNet peerings (created in both directions)
# -----------------------------------------------------------------------------
resource "azurerm_virtual_network_peering" "this" {
  for_each = var.peerings

  name                         = each.value.name
  resource_group_name          = var.resource_group_name
  virtual_network_name         = azurerm_virtual_network.this[each.value.local_vnet_key].name
  remote_virtual_network_id    = azurerm_virtual_network.this[each.value.remote_vnet_key].id
  allow_forwarded_traffic      = each.value.allow_forwarded_traffic
  allow_gateway_transit        = each.value.allow_gateway_transit
  allow_virtual_network_access = each.value.allow_virtual_network_access
  use_remote_gateways          = each.value.use_remote_gateways

  # A peering cannot be created while either VNet is still being updated by a
  # subnet operation (PutSubnetOperation). Wait until ALL subnets and their
  # NSG/NAT associations are fully provisioned on both VNets first.
  depends_on = [
    azurerm_subnet.this,
    azurerm_subnet_network_security_group_association.this,
    azurerm_subnet_nat_gateway_association.this,
  ]
}

# -----------------------------------------------------------------------------
# Private DNS zones + VNet links
# -----------------------------------------------------------------------------
resource "azurerm_private_dns_zone" "this" {
  for_each = var.private_dns_zones

  name                = each.value.name
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "this" {
  for_each = merge([
    for zone_key, zone in var.private_dns_zones : {
      for link_key, link in zone.vnet_links :
      "${zone_key}/${link_key}" => merge(link, { zone_key = zone_key })
    }
  ]...)

  name                  = each.value.name
  resource_group_name   = var.resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.this[each.value.zone_key].name
  virtual_network_id    = azurerm_virtual_network.this[each.value.vnet_key].id
  registration_enabled  = each.value.registration_enabled
  tags                  = var.tags
}
