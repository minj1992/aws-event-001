output "vnet_ids" {
  description = "Map of VNet logical key => VNet ID."
  value       = { for k, v in azurerm_virtual_network.this : k => v.id }
}

output "vnet_names" {
  description = "Map of VNet logical key => VNet name."
  value       = { for k, v in azurerm_virtual_network.this : k => v.name }
}

output "subnet_ids" {
  description = "Map of \"<vnet_key>/<subnet_key>\" => subnet ID."
  value       = { for k, v in azurerm_subnet.this : k => v.id }
}

output "nsg_ids" {
  description = "Map of NSG logical key => NSG ID."
  value       = { for k, v in azurerm_network_security_group.this : k => v.id }
}

output "public_ip_ids" {
  description = "Map of public IP logical key => ID."
  value       = { for k, v in azurerm_public_ip.this : k => v.id }
}

output "private_dns_zone_ids" {
  description = "Map of private DNS zone logical key => ID."
  value       = { for k, v in azurerm_private_dns_zone.this : k => v.id }
}
