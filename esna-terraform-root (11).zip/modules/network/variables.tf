variable "location" {
  description = "Azure region for all network resources."
  type        = string
}

variable "resource_group_name" {
  description = "Resource group that holds the network resources."
  type        = string
}

variable "tags" {
  description = "Tags applied to network resources."
  type        = map(string)
  default     = {}
}

# -----------------------------------------------------------------------------
# Virtual networks and their subnets
# -----------------------------------------------------------------------------
variable "virtual_networks" {
  description = <<-EOT
    Map of virtual networks to create, keyed by a logical name.
    Each VNet contains a map of subnets keyed by logical name.
  EOT
  type = map(object({
    name          = string
    address_space = list(string)
    dns_servers   = optional(list(string), [])
    subnets = map(object({
      name              = string
      address_prefixes  = list(string)
      service_endpoints = optional(list(string), [])
      # NSG association: logical key into var.network_security_groups (or null)
      nsg_key = optional(string)
      # NAT gateway association: logical key into var.nat_gateways (or null)
      nat_gateway_key = optional(string)
      # Optional subnet delegation (e.g. for PostgreSQL Flexible Server)
      delegation = optional(object({
        name         = string
        service_name = string
        actions      = list(string)
      }))
      private_endpoint_network_policies = optional(string, "Disabled")
    }))
  }))
  default = {}
}

# -----------------------------------------------------------------------------
# Network security groups and rules
# -----------------------------------------------------------------------------
variable "network_security_groups" {
  description = "Map of NSGs to create, each with a list of security rules."
  type = map(object({
    name = string
    rules = optional(list(object({
      name                       = string
      priority                   = number
      direction                  = string
      access                     = string
      protocol                   = string
      source_port_range          = optional(string, "*")
      destination_port_range     = optional(string, "*")
      source_address_prefix      = optional(string, "*")
      destination_address_prefix = optional(string, "*")
    })), [])
  }))
  default = {}
}

# -----------------------------------------------------------------------------
# Public IPs
# -----------------------------------------------------------------------------
variable "public_ips" {
  description = "Map of public IP addresses to create."
  type = map(object({
    name              = string
    sku               = optional(string, "Standard")
    allocation_method = optional(string, "Static")
    zones             = optional(list(string), [])
  }))
  default = {}
}

# -----------------------------------------------------------------------------
# NAT gateways
# -----------------------------------------------------------------------------
variable "nat_gateways" {
  description = "Map of NAT gateways. public_ip_key references var.public_ips."
  type = map(object({
    name                    = string
    sku_name                = optional(string, "Standard")
    idle_timeout_in_minutes = optional(number, 4)
    zones                   = optional(list(string), [])
    public_ip_key           = string
  }))
  default = {}
}

# -----------------------------------------------------------------------------
# Bastion host (optional)
# -----------------------------------------------------------------------------
variable "bastion" {
  description = "Optional Azure Bastion host. subnet_key and public_ip_key reference other maps."
  type = object({
    name          = string
    sku           = optional(string, "Basic")
    scale_units   = optional(number, 2)
    vnet_key      = string
    subnet_key    = string
    public_ip_key = string
  })
  default = null
}

# -----------------------------------------------------------------------------
# VNet peerings
# -----------------------------------------------------------------------------
variable "peerings" {
  description = "Map of VNet peerings. local/remote_vnet_key reference var.virtual_networks."
  type = map(object({
    name                         = string
    local_vnet_key               = string
    remote_vnet_key              = string
    allow_forwarded_traffic      = optional(bool, false)
    allow_gateway_transit        = optional(bool, false)
    allow_virtual_network_access = optional(bool, true)
    use_remote_gateways          = optional(bool, false)
  }))
  default = {}
}

# -----------------------------------------------------------------------------
# Private DNS zones (e.g. for PostgreSQL private access)
# -----------------------------------------------------------------------------
variable "private_dns_zones" {
  description = "Map of private DNS zones with optional VNet links."
  type = map(object({
    name = string
    vnet_links = optional(map(object({
      name                 = string
      vnet_key             = string
      registration_enabled = optional(bool, false)
    })), {})
  }))
  default = {}
}
