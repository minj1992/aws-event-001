# Resources created by the pipeline (per environment)

Region `uksouth`. Counts reflect the current code **after** the agreed changes:
ACR admin disabled + AcrPull role assignment, and the resource-creation
booleans (qa/prod reuse the shared dev jumpboxes, so they create no VM / NIC /
disk / shutdown-schedule resources).

The ~550 PostgreSQL default `*_configuration` blocks are Azure-managed defaults
and are not included. The backend state storage (RG + storage account +
container) is created by the pipeline's "ensure backend" stage and is not
counted here.

## Totals

| Environment | Resource count |
|---|---|
| dev | 52 |
| qa | 41 |
| prod | 40 |

## Breakdown by type

| Resource type | dev | qa | prod |
|---|:--:|:--:|:--:|
| azurerm_resource_group | 2 | 2 | 2 |
| azurerm_virtual_network | 2 | 2 | 2 |
| azurerm_subnet | 8 | 8 | 8 |
| azurerm_network_security_group | 2 | 2 | 2 |
| azurerm_subnet_network_security_group_association | 2 | 2 | 2 |
| azurerm_public_ip | 4 | 4 | 3 |
| azurerm_nat_gateway | 2 | 2 | 2 |
| azurerm_nat_gateway_public_ip_association | 2 | 2 | 2 |
| azurerm_subnet_nat_gateway_association | 2 | 2 | 2 |
| azurerm_bastion_host | 1 | 1 | 1 |
| azurerm_virtual_network_peering | 2 | 2 | 2 |
| azurerm_private_dns_zone | 1 | 1 | 1 |
| azurerm_private_dns_zone_virtual_network_link | 2 | 2 | 2 |
| azurerm_user_assigned_identity | 1 | 1 | 1 |
| azurerm_kubernetes_cluster | 1 | 1 | 1 |
| azurerm_role_assignment (AcrPull: AKS -> ACR) | 1 | 1 | 1 |
| azurerm_postgresql_flexible_server | 1 | 1 | 1 |
| azurerm_postgresql_flexible_server_database | 2 | 2 | 2 |
| azurerm_container_registry | 1 | 1 | 1 |
| azurerm_key_vault | 1 | 1 | 1 |
| azurerm_storage_account | 1 | 1 | 1 |
| azurerm_managed_disk | 1 | 0 | 0 |
| azurerm_snapshot | 1 | 0 | 0 |
| azurerm_network_interface | 3 | 0 | 0 |
| azurerm_windows_virtual_machine | 2 | 0 | 0 |
| azurerm_linux_virtual_machine | 1 | 0 | 0 |
| azurerm_dev_test_global_vm_shutdown_schedule | 3 | 0 | 0 |

## Resource-creation toggles (Terraform side)

Each major module has a master on/off boolean. Defaults and dependency rules:

| Toggle | dev | qa | prod | Notes / dependency |
|---|:--:|:--:|:--:|---|
| enable_aks | true | true | true | needs the network (always created) for the node subnet |
| enable_postgres | true | true | true | needs the delegated subnet + private DNS zone |
| enable_acr | true | true | true | — |
| enable_key_vault | true | true | true | — |
| enable_storage_account | true | true | true | — |
| enable_managed_disks | true | false | false | independent |
| enable_virtual_machines | true | false | false | jumpboxes; reuse shared dev ones |
| AcrPull role assignment | auto | auto | auto | created only when enable_aks AND enable_acr are both true |

**Always created (no toggle - foundational):** resource groups, the hub/app
network (VNets, subnets, NSGs, NAT, Bastion, peering, private DNS), and the
common-tags helper. Adding on/off switches to these would break every resource
that depends on them, so they are intentionally left always-on.

## Open items for the call

- **Naming convention** `esna-<env>-<type>-<resource>` - not yet applied; needs
  the `<type>` vocabulary agreed, then a single consistent pass.
- **Shared jumpbox networking** - qa/prod VNets are not peered to dev, so a
  shared dev jumpbox cannot currently reach qa/prod private resources. Decide
  where the shared jumpboxes live and add the necessary peering/routing.
